#include <Arduino.h>
String firmware = "0.04";
#define SerialMon Serial
#define SerialAT  Serial1
#include "utilities.h"

#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_ADS1X15.h>
#include <TimeLib.h>

#define TINY_GSM_MODEM_SIM7080
#define TINY_GSM_RX_BUFFER 1024
#define TINY_GSM_DEBUG SerialMon
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

#define XPOWERS_CHIP_AXP2101
#include "XPowersLib.h"

// ===================== DS18B20 =====================
#define DS18B20_POWER 16
#define DS18B20_DATA  17

OneWire oneWire(DS18B20_DATA);
DallasTemperature DS18B20(&oneWire);
float temp_DS18B20 = NAN;

// ===================== ADS1115 =====================
TwoWire ADS1115_I2C_2 = TwoWire(1);
Adafruit_ADS1115 ads_1115;

#define ADS_PWR_ADS1115 21
#define SDA_ADS1115     36
#define SCL_ADS1115     37
#define ADDR_ADS1115    0x48

#define TX2_POWER 14
#define TX2_DATA  13
int16_t TX2_Resultat = 0;
float distance = NAN;

// ===================== MODEM / MQTT =====================
//const char APN[]       = "internet.m2mportal.de";
const char APN[] = "iotsim.melita.io";
const char GPRS_USER[] = "";
const char GPRS_PASS[] = "";

const char MQTT_SERVER[]    = "mqtt.marxkrontal.com";
const int  MQTT_PORT        = 1883;
const char MQTT_USER[]      = "funksystemiot";
const char MQTT_PASS[]      = "4bx7aijN_mb?znh2T`T\"";
const char MQTT_CLIENT_ID[] = "1081ACA0ED30";
const char MQTT_TOPIC[]     = "test/funksystemiot/nbiot/07152_05/1081ACA0ED30";

// ===================== TIMING =====================
const uint32_t MEASUREMENT_INTERVAL_MS = 1000;   // 1 sek.
const uint32_t TRANSMIT_INTERVAL_SEC  = 60;      // 60 sek (1 min)


const uint16_t WINDOW_SAMPLES = TRANSMIT_INTERVAL_SEC * 1000 / MEASUREMENT_INTERVAL_MS;

// Weg sensor Kalebrierung
const float SENSOR_SPAN_MM = 10.0f;
const float WEG_MIN_RAW    = 0.0f;
const float WEG_MAX_RAW    = 16810.0f;

TinyGsm modem(SerialAT);
TinyGsmClient gsmClient(modem);
PubSubClient mqtt(gsmClient);

// ===================== PMU =====================
XPowersPMU PMU;

// ===================== GLOBALS =====================
bool connect_m = false;
float voltage = NAN;

int _year, _month, _day, _hour, _minute, _second;
float _tzone;
char netTime[32] = "no_time";



// период пересинхронизации времени
unsigned long lastTimeSyncMs = 0;
const unsigned long TIME_SYNC_INTERVAL_MS = 6UL * 60UL * 60UL * 1000UL;

// ===================== DATA STRUCT =====================
struct SensorStats {
  float temperature_min;
  float temperature_max;
  float temperature_avg;

  float distance_min;
  float distance_max;
  float distance_avg;

  int16_t raw_min;
  int16_t raw_max;
  float   raw_avg;

  float battery_voltage;
  int csq;
  char timestamp[32];
};

QueueHandle_t sensorQueue;

// ===================== PROTOTYPES =====================
bool initADS1115();
int16_t readAverageCh(uint8_t ch, uint8_t samples);
uint16_t Measure_ADS1115();
void Measure_DS18B20();

bool initModem();
void initPOWER();
void powerOnModem();
void powerOffModem();
bool connectMQTT();
void mqttCallback(char* topic, byte* payload, unsigned int length);

bool syncTimeFromNetwork();
time_t convertToUnixTime(int yr, int mon, int day, int hr, int min, int sec);
String unixToIsoUtc(time_t utc);

void taskMeasurements(void *param);
void taskMQTT(void *param);

// =====================================================
// ADS1115 INIT
// =====================================================
bool initADS1115() {
  ADS1115_I2C_2.begin(SDA_ADS1115, SCL_ADS1115, 400000);
  ads_1115.setGain(GAIN_TWOTHIRDS);
  ads_1115.setDataRate(RATE_ADS1115_128SPS);

  for (int i = 0; i < 5; i++) {
    if (ads_1115.begin(ADDR_ADS1115, &ADS1115_I2C_2)) return true;
    delay(20);
  }
  return false;
}

// =====================================================
// READ AVERAGE CHANNEL
// =====================================================
int16_t readAverageCh(uint8_t ch, uint8_t samples) {
  long sum = 0;
  for (uint8_t i = 0; i < samples; i++) {
    sum += ads_1115.readADC_SingleEnded(ch);
    delay(5);
  }
  long avg = sum / samples;
  if (avg < 0) avg = 0;
  if (avg > 32767) avg = 32767;
  return (int16_t)avg;
}

// =====================================================
// MEASURE ADS1115
// =====================================================
uint16_t Measure_ADS1115() {
  int16_t rawRef = readAverageCh(1, 8);  // CH1 = Vref
  int16_t rawSig = readAverageCh(0, 8);  // CH0 = sensor signal

  if (rawRef < 10) {
    SerialMon.printf("Vref zu klein/kein Kontakt (rawRef=%d)\n", rawRef);
    distance = NAN;
    return (uint16_t)rawSig;
  }

  float span = SENSOR_SPAN_MM;
  if (span < 0.1f || span > 100000.0f) span = 10.0f;

  float rawMin = WEG_MIN_RAW;
  float rawMax = WEG_MAX_RAW;

  float norm;

  if (rawMax == rawMin) {
    rawMin = 0.0f;
    rawMax = 32768.0f;
  }

  if (rawMax > rawMin) {
    norm = (rawSig - rawMin) / (rawMax - rawMin);
  } else {
    norm = (rawMin - rawSig) / (rawMin - rawMax);
  }

  if (norm < 0.0f) norm = 0.0f;
  if (norm > 1.0f) norm = 1.0f;

  distance = norm * span;

  const float FS = 6.144f;
  float vRef = rawRef * (FS / 32768.0f);
  float vSig = rawSig * (FS / 32768.0f);

  SerialMon.printf(
    "REF: %d (%.4f V) | SIG: %d (%.4f V) | norm=%.4f | dist=%.4f mm\n",
    rawRef, vRef,
    rawSig, vSig,
    norm,
    distance
  );

  return (uint16_t)rawSig;
}

// =====================================================
// MEASURE DS18B20
// =====================================================
void Measure_DS18B20() {
  DS18B20.requestTemperatures();
  delay(100);
  temp_DS18B20 = DS18B20.getTempCByIndex(0);

  SerialMon.printf("Temperatur DS18B20: %.2f °C\n", temp_DS18B20);
}

// =====================================================
// MODEM INIT
// =====================================================
bool initModem()
{
  SerialMon.println("Initialisiere Modem...");

  SerialAT.begin(115200, SERIAL_8N1, BOARD_MODEM_RXD_PIN, BOARD_MODEM_TXD_PIN);
  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);

  unsigned long startWait = millis();
  const unsigned long maxWait = 30UL * 1000UL;
  int retry = 0;

  while (!modem.testAT(1000)) {
    SerialMon.print(".");

    if (retry++ > 15) {
      SerialMon.println("\nModem wird neu gestartet...");
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
      delay(100);
      digitalWrite(BOARD_MODEM_PWR_PIN, HIGH);
      delay(1000);
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
      retry = 0;
    }

    if (millis() - startWait > maxWait) {
      SerialMon.println("\nModem antwortet nicht, Zeitüberschreitung!");
      break;
    }
  }

  if (modem.testAT(1000)) {
    SerialMon.println("Modem betriebsbereit.");
  } else {
    SerialMon.println("Fehler: Modem antwortet nicht.");
    return false;
  }

  String cnmp, cmnb;

  modem.sendAT("+CNMP?");
  if (modem.waitResponse(1000, cnmp) == 1 && cnmp.indexOf("+CNMP: 38") != -1) {
    SerialMon.println("CNMP bereits auf 38 gesetzt");
  } else {
    modem.sendAT("+CNMP=38");
    modem.waitResponse();
  }

  modem.sendAT("+CMNB?");
  if (modem.waitResponse(1000, cmnb) == 1 && cmnb.indexOf("+CMNB: 1") != -1) {
    SerialMon.println("CMNB bereits auf 1 gesetzt");
  } else {
    modem.sendAT("+CMNB=1");
    modem.waitResponse();
  }

  if (cnmp.indexOf("+CNMP: 38") == -1 || cmnb.indexOf("+CMNB: 1") == -1) {
    SerialMon.println("Modem wird neu gestartet, um Netzwerkeinstellungen anzuwenden...");
    modem.restart();
    delay(10000);
  }

  SerialMon.println(modem.getOperator());
  SerialMon.println(modem.getSignalQuality());
  SerialMon.println(modem.isNetworkConnected() ? "Verbunden" : "Nicht verbunden");

  if (!modem.gprsConnect(APN, GPRS_USER, GPRS_PASS)) {
    SerialMon.println("Verbindung mit dem NB-IoT-Netzwerk fehlgeschlagen.");
    connect_m = false;
    return false;
  }

  SerialMon.println("Mit dem NB-IoT-Netzwerk verbunden.");
  connect_m = true;
  return true;
}

// =====================================================
// POWER INIT
// =====================================================
void initPOWER()
{
  if (!PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
    SerialMon.println("Fehler bei der Initialisierung der Stromversorgung.");
    ESP.restart();
  }

  PMU.setChargeTargetVoltage(XPOWERS_AXP2101_CHG_VOL_4V2);
  PMU.setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);

  PMU.enableTemperatureMeasure(); 
  PMU.enableBattDetection(); 
  PMU.enableVbusVoltageMeasure(); 
  PMU.enableBattVoltageMeasure(); 
  PMU.enableSystemVoltageMeasure();

  PMU.disableDC2();
  PMU.disableDC4();
  PMU.disableDC5();
  PMU.disableALDO1();
  PMU.disableALDO2();
  PMU.disableALDO3();
  PMU.disableALDO4();
  PMU.disableBLDO2();
  PMU.disableCPUSLDO();
  PMU.disableDLDO1();
  PMU.disableDLDO2();

  if (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_UNDEFINED ) {
    PMU.disableDC3();
    delay(200);
  }

  PMU.setBLDO1Voltage(3300);
  PMU.enableBLDO1();

  PMU.setDC3Voltage(3000);

  PMU.setBLDO2Voltage(3300);
  PMU.enableBLDO2();

  PMU.setALDO3Voltage(3300);
  PMU.enableALDO3();

  PMU.disableTSPinMeasure();
}

// =====================================================
// POWER ON MODEM
// =====================================================
void powerOnModem()
{
  SerialMon.println("Power ON modem");

  PMU.enableDC3();
  delay(200);

  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);
  digitalWrite(BOARD_MODEM_PWR_PIN, HIGH);
  delay(500);
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);

  delay(2000);
}


bool getNetworkTimestamp(char* out, size_t outSize)
{
  int year, month, day, hour, minute, second;
  float timezone;

  if (!modem.getNetworkTime(&year, &month, &day, &hour, &minute, &second, &timezone)) {
    SerialMon.println("Не удалось получить время от оператора");
    return false;
  }

  time_t localUnixTime = convertToUnixTime(year, month, day, hour, minute, second);
  time_t utcUnixTime = localUnixTime - (time_t)(timezone * 3600);

  String iso = unixToIsoUtc(utcUnixTime);

  memset(out, 0, outSize);
  iso.toCharArray(out, outSize);

  SerialMon.printf("Operator time: %s\n", out);
  return true;
}

// =====================================================
// POWER OFF MODEM
// =====================================================
void powerOffModem()
{
  SerialMon.println("Power OFF modem");

  modem.poweroff();
  delay(1000);

  PMU.disableDC3();
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
}

// =====================================================
// MQTT CONNECT
// =====================================================
bool connectMQTT()
{
  SerialMon.println("Verbinde mit MQTT-Broker...");
  const int maxAttempts = 5;
  int attempt = 0;

  while (!mqtt.connected() && attempt < maxAttempts) {
    attempt++;
    SerialMon.print("Attempt ");
    SerialMon.print(attempt);
    SerialMon.println(" to connect to MQTT broker...");

    if (mqtt.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS)) {
      SerialMon.println("Mit MQTT-Broker verbunden!");
      connect_m = true;
      return true;
    } else {
      SerialMon.print("Fehler bei der MQTT-Broker-Verbindung, Code=");
      SerialMon.println(mqtt.state());
      delay(2000);
    }
  }

  SerialMon.println("Failed to connect to MQTT broker after 5 attempts.");
  connect_m = false;
  return false;
}

// =====================================================
// MQTT CALLBACK
// =====================================================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  SerialMon.print("MQTT RX [");
  SerialMon.print(topic);
  SerialMon.print("]: ");

  for (unsigned int i = 0; i < length; i++) {
    SerialMon.print((char)payload[i]);
  }
  SerialMon.println();
}

// =====================================================
// TIME HELPERS
// =====================================================
time_t convertToUnixTime(int yr, int mon, int day, int hr, int min, int sec) {
  tmElements_t tm;
  tm.Year = yr >= 1970 ? yr - 1970 : yr;
  tm.Month = mon;
  tm.Day = day;
  tm.Hour = hr;
  tm.Minute = min;
  tm.Second = sec;
  return makeTime(tm);
}

String unixToIsoUtc(time_t utc) {
  tmElements_t tm;
  breakTime(utc, tm);

  char buf[25];
  int year = tm.Year + 1970;

  snprintf(buf, sizeof(buf),
           "%04d-%02d-%02dT%02d:%02d:%02d.000Z",
           year, tm.Month, tm.Day, tm.Hour, tm.Minute, tm.Second);

  return String(buf);
}

// =====================================================
// TIME SYNC
// =====================================================
bool syncTimeFromNetwork()
{
  if (modem.getNetworkTime(&_year, &_month, &_day, &_hour, &_minute, &_second, &_tzone)) {
    time_t localUnixTime = convertToUnixTime(_year, _month, _day, _hour, _minute, _second);
    time_t unixTime = localUnixTime - (time_t)(_tzone * 3600);
    String iso = unixToIsoUtc(unixTime);

    memset(netTime, 0, sizeof(netTime));
    iso.toCharArray(netTime, sizeof(netTime));

    SerialMon.printf("Netzwerkzeit: %s\n", netTime);
    lastTimeSyncMs = millis();
    return true;
  }

  SerialMon.println("Abrufen der Netzwerkzeit fehlgeschlagen!");
  return false;
}

// =====================================================
// TASK 1: MEASUREMENTS
// =====================================================
void taskMeasurements(void *param)
{
  //const uint16_t WINDOW_SAMPLES = 60;

  TickType_t lastWakeTime = xTaskGetTickCount();

  SensorStats stats;
  uint16_t sampleCount = 0;

  float tempSum = 0.0f;
  float distSum = 0.0f;
  long rawSum = 0;

  uint16_t validTempCount = 0;
  uint16_t validDistCount = 0;
  uint16_t validRawCount  = 0;

  auto resetStats = [&]() {
    stats.temperature_min = NAN;
    stats.temperature_max = NAN;
    stats.temperature_avg = NAN;

    stats.distance_min = NAN;
    stats.distance_max = NAN;
    stats.distance_avg = NAN;

    stats.raw_min = INT16_MAX;
    stats.raw_max = INT16_MIN;
    stats.raw_avg = NAN;

    stats.battery_voltage = NAN;


    tempSum = 0.0f;
    distSum = 0.0f;
    rawSum = 0;

    validTempCount = 0;
    validDistCount = 0;
    validRawCount  = 0;

    sampleCount = 0;
  };

  resetStats();

  SerialMon.println("Continuous measurement task started");

  while (true) {
    vTaskDelayUntil(&lastWakeTime, pdMS_TO_TICKS(MEASUREMENT_INTERVAL_MS));

    voltage = PMU.getBattVoltage() / 1000.0f;
    stats.battery_voltage = voltage;

    TX2_Resultat = (int16_t)Measure_ADS1115();
    Measure_DS18B20();

    SerialMon.printf("Sample %u | Battery: %.3f V\n", sampleCount + 1, voltage);

    // Temperature
    if (!isnan(temp_DS18B20) && temp_DS18B20 > -100.0f && temp_DS18B20 < 150.0f) {
      if (isnan(stats.temperature_min) || temp_DS18B20 < stats.temperature_min) {
        stats.temperature_min = temp_DS18B20;
      }
      if (isnan(stats.temperature_max) || temp_DS18B20 > stats.temperature_max) {
        stats.temperature_max = temp_DS18B20;
      }
      tempSum += temp_DS18B20;
      validTempCount++;
    }

    // Distance
    if (!isnan(distance)) {
      if (isnan(stats.distance_min) || distance < stats.distance_min) {
        stats.distance_min = distance;
      }
      if (isnan(stats.distance_max) || distance > stats.distance_max) {
        stats.distance_max = distance;
      }
      distSum += distance;
      validDistCount++;
    }

    // Raw
    if (TX2_Resultat >= 0) {
      if (TX2_Resultat < stats.raw_min) stats.raw_min = TX2_Resultat;
      if (TX2_Resultat > stats.raw_max) stats.raw_max = TX2_Resultat;
      rawSum += TX2_Resultat;
      validRawCount++;
    }

    sampleCount++;

    if (sampleCount >= WINDOW_SAMPLES) {
      if (validTempCount > 0) {
        stats.temperature_avg = tempSum / validTempCount;
      }

      if (validDistCount > 0) {
        stats.distance_avg = distSum / validDistCount;
      }

      if (validRawCount > 0) {
        stats.raw_avg = (float)rawSum / (float)validRawCount;
      } else {
        stats.raw_min = 0;
        stats.raw_max = 0;
      }



      SerialMon.println("1-minute window complete");
      SerialMon.printf("TEMP min=%.2f max=%.2f avg=%.2f\n",
                       stats.temperature_min, stats.temperature_max, stats.temperature_avg);
      SerialMon.printf("DIST min=%.4f max=%.4f avg=%.4f\n",
                       stats.distance_min, stats.distance_max, stats.distance_avg);
      SerialMon.printf("RAW  min=%d max=%d avg=%.2f\n",
                       stats.raw_min, stats.raw_max, stats.raw_avg);

      // отправляем без блокировки измерений
      xQueueOverwrite(sensorQueue, &stats);

      // сразу начинаем следующее минутное окно
      resetStats();
    }
  }
}
// =====================================================
// TASK 2: MQTT
// =====================================================
void taskMQTT(void *param)
{
  SensorStats stats;

  while (true) {
    if (!mqtt.connected()) {
      connectMQTT();
    }

    mqtt.loop();

    if (millis() - lastTimeSyncMs > TIME_SYNC_INTERVAL_MS) {
      syncTimeFromNetwork();
    }

    if (xQueueReceive(sensorQueue, &stats, pdMS_TO_TICKS(1000)) == pdTRUE) {
      if (!mqtt.connected()) {
        if (!connectMQTT()) {
          SerialMon.println("MQTT unavailable, packet skipped");
          continue;
        }
      }
      if (!getNetworkTimestamp(stats.timestamp, sizeof(stats.timestamp))) {
        strncpy(stats.timestamp, "no_time", sizeof(stats.timestamp) - 1);
        stats.timestamp[sizeof(stats.timestamp) - 1] = '\0';
      }
      stats.csq = modem.getSignalQuality();
      SerialMon.print("Signalqualität (CSQ): ");
      SerialMon.println(stats.csq);
      
      StaticJsonDocument<512> doc;

      doc["Timestamp"] = stats.timestamp;
      doc["ControllerID"] = MQTT_CLIENT_ID;
      //doc["Firmware"] = firmware;
      doc["Batteriespannung"] = stats.battery_voltage;

      if (!isnan(stats.temperature_min)) doc["temperature_min"] = stats.temperature_min;
      else doc["temperature_min"] = nullptr;

      if (!isnan(stats.temperature_max)) doc["temperature_max"] = stats.temperature_max;
      else doc["temperature_max"] = nullptr;

      if (!isnan(stats.temperature_avg)) doc["temperature_avg"] = stats.temperature_avg;
      else doc["temperature_avg"] = nullptr;

      if (!isnan(stats.distance_min)) doc["distance_min"] = stats.distance_min;
      else doc["distance_min"] = nullptr;

      if (!isnan(stats.distance_max)) doc["distance_max"] = stats.distance_max;
      else doc["distance_max"] = nullptr;

      if (!isnan(stats.distance_avg)) doc["distance_avg"] = stats.distance_avg;
      else doc["distance_avg"] = nullptr;

      doc["csq"] = stats.csq;
      //doc["raw_min"] = stats.raw_min;
      //doc["raw_max"] = stats.raw_max;

      //if (!isnan(stats.raw_avg)) doc["raw_avg"] = stats.raw_avg;
      //else doc["raw_avg"] = nullptr;

      char payload[512];
      size_t len = serializeJson(doc, payload, sizeof(payload));

      bool ok = mqtt.publish(MQTT_TOPIC, payload, len);

      SerialMon.println("MQTT payload:");
      SerialMon.println(payload);

      if (ok) SerialMon.println("Publish OK");
      else    SerialMon.println("Publish FAILED");
    }

    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

// =====================================================
// SETUP
// =====================================================
void setup()
{
  Serial.begin(115200);
  delay(500);
  SerialMon.begin(115200);
  delay(1000);

  SerialMon.println();
  SerialMon.println("========== START ==========");

  initPOWER();

  pinMode(ADS_PWR_ADS1115, OUTPUT);
  pinMode(TX2_POWER, OUTPUT);
  pinMode(DS18B20_POWER, OUTPUT);

  // питание датчиков постоянно включено
  digitalWrite(ADS_PWR_ADS1115, HIGH);
  digitalWrite(TX2_POWER, HIGH);
  digitalWrite(DS18B20_POWER, HIGH);

  delay(300);

  DS18B20.begin();
  SerialMon.println("DS18B20 initialized");
  DS18B20.setResolution(9);

  if (!initADS1115()) {
    SerialMon.println("ADS1115 nicht gefunden!");
  } else {
    SerialMon.println("ADS1115 initialized");
  }

  powerOnModem();

  if (!initModem()) {
    SerialMon.println("Modem init failed");
  }

  syncTimeFromNetwork();

  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  mqtt.setBufferSize(512);

  connectMQTT();

 sensorQueue = xQueueCreate(1, sizeof(SensorStats)); 
  if (sensorQueue == NULL) {
    SerialMon.println("Queue create failed");
    while (true) {
      delay(1000);
    }
  }

  xTaskCreatePinnedToCore(
    taskMeasurements,
    "taskMeasurements",
    8192,
    NULL,
    1,
    NULL,
    1
  );

  xTaskCreatePinnedToCore(
    taskMQTT,
    "taskMQTT",
    8192,
    NULL,
    1,
    NULL,
    0
  );

  SerialMon.println("Tasks started");
}

// =====================================================
// LOOP
// =====================================================
void loop()
{
  vTaskDelay(pdMS_TO_TICKS(1000));
}