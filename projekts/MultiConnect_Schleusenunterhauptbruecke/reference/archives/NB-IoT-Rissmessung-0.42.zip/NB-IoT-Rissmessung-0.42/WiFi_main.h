/* ===================== WEB СКЕТЧ (WiFi_main.h) (изменённый) ===================== */
#pragma once

/* ====== Access Point defaults ======
   Параметры настраиваются через Web UI и хранятся в NVS ("cfg").
   Эти значения — только дефолты (factory reset / первый запуск).
*/
static const char* AP_SSID_BASE    = "NB-IoT-RM";
static const char* AP_PASS_DEF     = "mkp-12345";
static const int   AP_CHANNEL_DEF  = 6;
static const int   AP_MAX_CONN_DEF = 4;

#include <FS.h>
#include "logo.h" // logo_png / logo_png_len (PROGMEM)

/* ====== Forward externs from main ====== */
extern Preferences preferences;
extern WebServer server;
extern String deviceID;
extern String firmware;
extern float temp_DS18B20;
extern float distance;
extern XPowersPMU PMU;

// ====== NEW: sensor port connected flags from main ======
extern bool temp_port_connected; // IO18
extern bool weg_port_connected;  // IO12
// ========================================================

extern Config cfg;
extern int messInterval;
extern int sendInterval;
extern unsigned long boot_ms;

/* ====== bool parser (FIX for checkbox: on/1/true) ====== */
static bool argToBool(const String& v){
  String s = v;
  s.toLowerCase();
  return (s == "1" || s == "true" || s == "on" || s == "yes");
}

/* ====== Apply cfg intervals to runtime ====== */
static void applyRuntimeIntervalsFromCfgNow(){
  if (cfg.messInterval_min < 1) cfg.messInterval_min = 1;
  if (cfg.sendInterval_cycles < 1) cfg.sendInterval_cycles = 1;
  messInterval = cfg.messInterval_min;
  sendInterval = cfg.sendInterval_cycles;
}

/* ====== Utils ====== */
void loadDefaults(Config& c){
  c.apn               = apn;
  c.gprsUser          = gprsUser;
  c.gprsPass          = gprsPass;

  c.mqtt_server       = mqtt_server;
  c.mqtt_port         = mqtt_port;
  c.mqtt_user         = mqtt_user;
  c.mqtt_pass         = mqtt_pass;
  c.mqtt_client_id    = mqtt_client_id;
  c.mqtt_topic        = mqtt_topic;
  c.mqtt_config_topic = mqtt_config_topic;

  c.sensor_span_mm    = 10.0f;
  c.weg_min_raw = 0.0f;
  c.weg_max_raw = 32767.0f;

  c.ap_ssid     = String(AP_SSID_BASE) + "-" + deviceID;
  c.ap_pass     = String(AP_PASS_DEF);
  c.ap_channel  = AP_CHANNEL_DEF;
  c.ap_max_conn = AP_MAX_CONN_DEF;

  // NEW: defaults must be 1 and 1 if not set
  c.messInterval_min       = 1;
  c.sendInterval_cycles    = 1;
  c.remote_conf_on         = true;
}

void loadFromNVS(Config& c){
  preferences.begin("cfg", true);

  bool hasAny = preferences.isKey("apn")
             || preferences.isKey("mqtt_server")
             || preferences.isKey("sensor_span_mm")
             || preferences.isKey("ap_ssid")
             || preferences.isKey("ap_pass")
             || preferences.isKey("ap_channel")
             || preferences.isKey("ap_max_conn")
             // ONLY new keys, no old keys:
             || preferences.isKey("messInterval")
             || preferences.isKey("sendInterval")
             || preferences.isKey("remote_conf_on")
             || preferences.isKey("weg_min_raw")
             || preferences.isKey("weg_max_raw");

  if(!hasAny){ preferences.end(); loadDefaults(c); return; }

  c.apn               = preferences.getString("apn", apn);
  c.gprsUser          = preferences.getString("gprsUser", gprsUser);
  c.gprsPass          = preferences.getString("gprsPass", gprsPass);

  c.mqtt_server       = preferences.getString("mqtt_server", mqtt_server);
  c.mqtt_port         = preferences.getInt   ("mqtt_port",   mqtt_port);
  c.mqtt_user         = preferences.getString("mqtt_user",   mqtt_user);
  c.mqtt_pass         = preferences.getString("mqtt_pass",   mqtt_pass);
  c.mqtt_client_id    = preferences.getString("mqtt_client_id",    mqtt_client_id);
  c.mqtt_topic        = preferences.getString("mqtt_topic",        mqtt_topic);
  c.mqtt_config_topic = preferences.getString("mqtt_cfg_topic",    mqtt_config_topic);

  c.sensor_span_mm    = preferences.getFloat("sensor_span_mm", 10.0f);
  if (c.sensor_span_mm < 0.1f || c.sensor_span_mm > 100000.0f) c.sensor_span_mm = 10.0f;

  String defSsid = String(AP_SSID_BASE) + "-" + deviceID;
  c.ap_ssid     = preferences.getString("ap_ssid", defSsid);
  c.ap_pass     = preferences.getString("ap_pass", String(AP_PASS_DEF));
  c.ap_channel  = preferences.getInt("ap_channel", AP_CHANNEL_DEF);
  c.ap_max_conn = preferences.getInt("ap_max_conn", AP_MAX_CONN_DEF);

  // ONLY new keys (no legacy)
  c.messInterval_min       = preferences.getInt("messInterval", 1);
  c.sendInterval_cycles    = preferences.getInt("sendInterval", 1);
  c.remote_conf_on         = preferences.getInt("remote_conf_on", 1);

  // validation
  if (c.ap_ssid.length() == 0) c.ap_ssid = defSsid;
  if (c.ap_channel < 1 || c.ap_channel > 13) c.ap_channel = AP_CHANNEL_DEF;
  if (c.ap_max_conn < 1 || c.ap_max_conn > 8) c.ap_max_conn = AP_MAX_CONN_DEF;
  if (c.ap_pass.length() > 0 && c.ap_pass.length() < 8) c.ap_pass = String(AP_PASS_DEF);

  if (c.messInterval_min < 1) c.messInterval_min = 1;
  if (c.sendInterval_cycles < 1) c.sendInterval_cycles = 1;

  c.weg_min_raw = preferences.getFloat("weg_min_raw", 0.0f);
  c.weg_max_raw = preferences.getFloat("weg_max_raw", 32767.0f);

  if (c.weg_max_raw == c.weg_min_raw) {
    c.weg_min_raw = 0.0f;
    c.weg_max_raw = 32767.0f;
  }

  preferences.end();
}




bool saveToNVS(const Config& c){
  Serial.printf("c.remote_conf_on = %d\n", c.remote_conf_on ? 1 : 0);
  Serial.printf("sizeof(c.remote_conf_on) = %u\n",
              sizeof(c.remote_conf_on));
  preferences.begin("cfg", false);

  preferences.putString("apn",            c.apn);
  preferences.putString("gprsUser",       c.gprsUser);
  preferences.putString("gprsPass",       c.gprsPass);
  preferences.putString("mqtt_server",    c.mqtt_server);
  preferences.putInt   ("mqtt_port",      c.mqtt_port);
  preferences.putString("mqtt_user",      c.mqtt_user);
  preferences.putString("mqtt_pass",      c.mqtt_pass);
  preferences.putString("mqtt_client_id", c.mqtt_client_id);
  preferences.putString("mqtt_topic",     c.mqtt_topic);
  preferences.putString("mqtt_cfg_topic", c.mqtt_config_topic);

  preferences.putFloat ("sensor_span_mm", c.sensor_span_mm);
  preferences.putFloat("weg_min_raw", c.weg_min_raw);
  preferences.putFloat("weg_max_raw", c.weg_max_raw);

  preferences.remove("remote_conf_on");
  preferences.putInt("remote_conf_on", c.remote_conf_on ? 1 : 0);


  preferences.putString("ap_ssid", c.ap_ssid);
  preferences.putString("ap_pass", c.ap_pass);
  preferences.putInt("ap_channel", c.ap_channel);
  preferences.putInt("ap_max_conn", c.ap_max_conn);

  // NEW keys only
  preferences.putInt ("messInterval", c.messInterval_min);
  preferences.putInt ("sendInterval", c.sendInterval_cycles);
  
  preferences.end();


  Preferences p;
  p.begin("cfg", true);

  if (p.isKey("remote_conf_on")) {
    int v = p.getInt("remote_conf_on");  // 0 или 1
    Serial.printf("READBACK remote_conf_on=%d\n", v);
  } else {
    Serial.println("READBACK remote_conf_on=NAN");
    }

  p.end();
  return true;
}


String configToJson(const Config& c){
  StaticJsonDocument<1300> doc;
  doc["apn"]               = c.apn;
  doc["gprsUser"]          = c.gprsUser;
  doc["gprsPass"]          = c.gprsPass;
  doc["mqtt_server"]       = c.mqtt_server;
  doc["mqtt_port"]         = c.mqtt_port;
  doc["mqtt_user"]         = c.mqtt_user;
  doc["mqtt_pass"]         = c.mqtt_pass;
  doc["mqtt_client_id"]    = c.mqtt_client_id;
  doc["mqtt_topic"]        = c.mqtt_topic;
  doc["mqtt_config_topic"] = c.mqtt_config_topic;

  doc["sensor_span_mm"]    = c.sensor_span_mm;
  doc["weg_min_raw"] = c.weg_min_raw;
  doc["weg_max_raw"] = c.weg_max_raw;

  doc["ap_ssid"]           = c.ap_ssid;
  doc["ap_pass"]           = c.ap_pass;
  doc["ap_channel"]        = c.ap_channel;
  doc["ap_max_conn"]       = c.ap_max_conn;

  doc["messInterval"]      = c.messInterval_min;
  doc["sendInterval"]      = c.sendInterval_cycles;
  doc["remote_conf_on"]    = c.remote_conf_on;

  String out; serializeJson(doc, out); return out;
}

// Teil-Update aus JSON mit Validierung
bool mergeJsonIntoConfig(const String& body, Config& out, String& err){
  StaticJsonDocument<1600> doc;
  DeserializationError e = deserializeJson(doc, body);
  if(e){ err = String("JSON-Parser-Fehler: ") + e.c_str(); return false; }

  auto setStr = [&](const char* key, String& dst)->bool{
    if(!doc.containsKey(key)) return true;
    if(!doc[key].is<const char*>()) { err = String("Feld '")+key+"' muss String sein"; return false; }
    dst = (const char*)doc[key]; return true;
  };
  auto setInt = [&](const char* key, int& dst)->bool{
    if(!doc.containsKey(key)) return true;
    if(!doc[key].is<long>() && !doc[key].is<int>()) { err = String("Feld '")+key+"' muss Integer sein"; return false; }
    dst = doc[key].as<int>(); return true;
  };
  auto setBool = [&](const char* key, bool& dst)->bool{
    if(!doc.containsKey(key)) return true;
    if(!doc[key].is<bool>() && !doc[key].is<long>() && !doc[key].is<int>()){
      err = String("Feld '")+key+"' muss Bool sein"; return false;
    }
    dst = doc[key].as<bool>(); return true;
  };
  auto setFloat = [&](const char* key, float& dst, float mn, float mx)->bool{
    if(!doc.containsKey(key)) return true;
    if(!doc[key].is<float>() && !doc[key].is<double>() && !doc[key].is<long>() && !doc[key].is<int>()){
      err = String("Feld '")+key+"' muss Zahl sein"; return false;
    }
    float v = doc[key].as<float>();
    if(v < mn || v > mx){ err = String("Feld '")+key+"' außerhalb des Bereichs"; return false; }
    dst = v; return true;
  };

  if(!setStr("apn", out.apn)) return false;
  if(!setStr("gprsUser", out.gprsUser)) return false;
  if(!setStr("gprsPass", out.gprsPass)) return false;

  if(!setStr("mqtt_server", out.mqtt_server)) return false;
  if(!setInt("mqtt_port", out.mqtt_port)) return false;
  if(!setStr("mqtt_user", out.mqtt_user)) return false;
  if(!setStr("mqtt_pass", out.mqtt_pass)) return false;
  if(!setStr("mqtt_client_id", out.mqtt_client_id)) return false;
  if(!setStr("mqtt_topic", out.mqtt_topic)) return false;
  if(!setStr("mqtt_config_topic", out.mqtt_config_topic)) return false;

  if(!setFloat("sensor_span_mm", out.sensor_span_mm, 0.1f, 100000.0f)) return false;
  if(!setFloat("weg_min_raw", out.weg_min_raw, -1000000.0f, 1000000.0f)) return false;
  if(!setFloat("weg_max_raw", out.weg_max_raw, -1000000.0f, 1000000.0f)) return false;

  if(out.weg_max_raw <= out.weg_min_raw){
    err = "weg_max_raw muss > weg_min_raw sein";
    return false;
  }

  if(!setStr("ap_ssid", out.ap_ssid)) return false;
  if(!setStr("ap_pass", out.ap_pass)) return false;
  if(!setInt("ap_channel", out.ap_channel)) return false;
  if(!setInt("ap_max_conn", out.ap_max_conn)) return false;

  // NEW keys
  if(!setInt("messInterval", out.messInterval_min)) return false;
  if(!setInt("sendInterval", out.sendInterval_cycles)) return false;
  if(!setInt("remote_conf_on", out.remote_conf_on)) return false;

  // Validate
  if(out.apn.length()==0){ err="APN erforderlich"; return false; }
  if(out.mqtt_server.length()==0){ err="MQTT-Server erforderlich"; return false; }
  if(out.mqtt_client_id.length()==0){ err="Client-ID erforderlich"; return false; }
  if(out.mqtt_topic.length()==0){ err="Topic erforderlich"; return false; }
  if(out.mqtt_config_topic.length()==0){ err="Config-Topic erforderlich"; return false; }

  if(out.ap_ssid.length()==0){ err="AP SSID erforderlich"; return false; }
  if(out.ap_channel < 1 || out.ap_channel > 13){ err="AP Kanal 1..13"; return false; }
  if(out.ap_max_conn < 1 || out.ap_max_conn > 8){ err="AP Max Conn 1..8"; return false; }
  if(out.ap_pass.length()>0 && out.ap_pass.length()<8){ err="AP Passwort минимум 8 Zeichen (oder leer)"; return false; }

  if(out.messInterval_min < 1){ err="messInterval min 1"; return false; }
  if(out.sendInterval_cycles < 1){ err="sendInterval min 1"; return false; }

  return true;
}

/* ====== Device ID ====== */
String makeDeviceId(){
  uint64_t chipid = ESP.getEfuseMac();
  char chipIdStr[20];
  sprintf(chipIdStr, "%04X%08X", (uint16_t)(chipid >> 32), (uint32_t)chipid);
  String id = String(chipIdStr);
  SerialMon.println("Device ID: " + id);
  return id;
}

/* ====== HTML / UI ====== */
static const char PAGE_HTML[] PROGMEM = R"HTML(
<!doctype html><html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>T-SIM7080-S3</title>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  html, body { height:100%; }
  body{
    font-family:system-ui,Segoe UI,Roboto,Arial;
    margin:0;
    background:#f7f9fc;
    color:#1a1a1a;
    min-height:100vh;
    overflow-x:hidden;
  }

  /* ===== Layout (Desktop-first) ===== */
  .wrap{
    width:100%;
    margin:0 auto;
    padding:18px 18px;
  }
  .card{
    width:100%;
    max-width:1180px;
    margin:0 auto;
    background:#f1f3f7;
    padding:18px 18px 16px;
    box-shadow:0 6px 20px rgba(0,0,0,0.06);
    border-radius:14px;
    min-height:auto;
    display:flex;
    flex-direction:column;
    gap:8px;
  }

  h1{margin:0 0 8px; font-size:22px}

  .logo{ display:flex; align-items:center; gap:14px; margin:2px 0 10px; }
  .logo img{ max-height:46px; width:auto; }
  .logo span{ font-weight:800; font-size:22px; color:#003366; }

  /* Tabs: on desktop no horizontal scroll, evenly spaced */
  .tabs{
    display:flex;
    gap:10px;
    margin:6px 0 12px 0;
    overflow:visible;
    flex-wrap:wrap;
  }

  .topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin:6px 0 12px;
  }

  .top-actions{
    display:flex;
    gap:10px;
  }

  .icon-btn{
    width:44px;
    height:44px;
    border:none;
    border-radius:12px;
    background:#3c57ff;
    color:#fff;
    font-size:22px;
    cursor:pointer;
    box-shadow:0 6px 16px rgba(60,87,255,.22);
  }

  .icon-btn:hover{
    transform:translateY(-1px);
  }

  .tabbtn{
    appearance:none;
    border:none;
    border-radius:10px;
    padding:0 18px;
    height:42px;
    font-weight:700;
    cursor:pointer;
    background:#e6ebf5;
    color:#1a1a1a;
    border:1px solid #ccd6ee;
    white-space:nowrap;
  }
  .tabbtn.active{
    background:#3c57ff;
    color:#fff;
    box-shadow:0 6px 16px rgba(60,87,255,.22);
  }

  /* Tabs visibility (важно: перебиваем специфичность #view-info{display:grid}) */
  .view{ display:none !important; }
  .view.active{ display:block !important; }

  /* Для конкретных вкладок задаём нужный тип отображения */
  #view-info.view.active{ display:grid !important; }   /* Info остаётся grid только когда активна */
  #view-config.view.active{ display:grid !important; }
  #view-log.view.active{ display:block !important; }

  fieldset{
    border:1px solid #bfc8e6;
    border-radius:12px;
    margin:10px 0;
    padding:12px;
    background:#eef1f6;
  }
  legend{
    opacity:.9;
    padding:0 6px;
    font-size:13px;
    font-weight:800;
    color:#1f2937;
    letter-spacing:0.2px;
  }

  /* ===== Form grid for desktop =====
  /* ===== Konfiguration: layout like your mock (cards grid) ===== */
@media (min-width: 980px){

  /* 3 колонки именно для формы */
  #view-config form#f{
    display:grid;
    grid-template-columns: repeat(3, minmax(320px, 1fr));
    gap:16px 18px;
    align-items:start;
  }

  /* карточки формы */
  #view-config form#f fieldset{
    margin:0;
    height:100%;
  }

  /* JSON Import + Zurücksetzen: 2 колонки под формой */
  #view-config > fieldset{
    margin:16px 0 0;
  }

  #view-config{
    /* чтобы form и нижние fieldset'ы красиво шли один за другим */
    gap:0;
  }
}



  label{
    display:flex;
    flex-direction:column;
    font-size:13px;
    margin-top:0;
    font-weight:700;
    color:#1f2937;
    min-width:0;
  }

  /* Чекбокс-строка: label с inline style="...display:flex..." */
  label[style*="display:flex"]{
    flex-direction:row !important;
    align-items:center !important;
    gap:8px !important;
    flex-wrap:wrap;
  }

  label[style*="display:flex"] > input[type="checkbox"]{
    margin-top:0 !important;
  }

  input, textarea, select{
    width:100%;
    padding:10px 12px;
    border-radius:10px;
    border:1px solid #ccd6ee;
    background:#ffffff;
    color:#1a1a1a;
    margin-top:5px;
  }
  input:focus, textarea:focus, select:focus{
    outline:none;
    border-color:#3c57ff;
    background:#f0f4ff;
  }
  textarea{ min-height:110px; resize:vertical; }

  /* Checkbox row: keep your inline style working; just make it nicer on desktop */
  input[type="checkbox"]{ accent-color:#3c57ff; }

  /* Aktionen: кнопки вертикально, на всю ширину блока */
  #fs-actions .btns.actions{
    flex-direction:column;
  }
  #fs-actions .btns.actions > *{
    flex: 1 1 auto;
    width:100%;
  }

  .btns{
    display:flex;
    gap:10px;
    margin-top:8px;
    flex-wrap:wrap;
  }

  .import-row{
    display:flex;
    align-items:flex-end;
    gap:10px;
  }

  .import-file{
    flex:1;
  }

  .btn-import{
    width:auto;
    min-width:140px;
    height:42px;
    margin:0;
    flex-shrink:0;
  }
  .btn-import{
    margin-top:10px;
    width:auto;
    min-width:160px;
    height:38px;
    padding:0 14px;
    font-size:14px;
  }

  .btn, button{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    height:44px;
    padding:0 16px;
    border:none;
    border-radius:10px;
    font-weight:700;
    cursor:pointer;
    background:#3c57ff;
    color:#fff;
    text-decoration:none;
    box-shadow:0 6px 16px rgba(60,87,255,.22);
  }
  .btns > a.btn, .btns > button{ flex:1 1 260px; }

  button.outline, .btn.outline{ background:transparent; border:1px solid #3c57ff; color:#3c57ff }
  .danger{ background:#e53935 !important; color:#fff !important; border:none !important; }
  .danger.outline{ background:transparent !important; color:#e53935 !important; border:1px solid #e53935 !important; }

  .note{ font-size:12px; opacity:.75; margin-top:4px; line-height:1.35; }
  .ok{ color:#2ed573 } .err{ color:#ff6b6b }

  /* ===== Info view layout ===== */
  .pill{
    border:1px solid #bfc8e6;
    border-radius:12px;
    padding:10px 12px;
    margin:8px 0;
    background:#e9edf5;
  }
  .label{ opacity:.75; font-size:12px; font-weight:700; color:#374151; }
  .value{ font-size:16px; margin-top:3px; }

  #view-info{
      display:grid;
      grid-template-columns: repeat(3, minmax(280px, 1fr));
      gap:12px;
      align-items:start;
  }

  #view-info > .pill{
      margin:0;
  }

  #view-info > fieldset{
      margin:0;
      grid-column:auto;
  }

  /* ===== Log view ===== */
  #view-log .pill{ border:none; background:transparent; padding:0; margin:0; }
  #logbox{
    white-space:pre-wrap;
    font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    height: calc(100vh - 300px);
    overflow:auto;
    border:none;
    border-radius:12px;
    padding:12px;
    background:#0b0f16;
    color:#d8dee9;
  }
  .log-actions{ display:flex; gap:10px; margin-top:10px; flex-wrap:wrap; }
  .log-actions .btn, .log-actions a.btn{ flex:1 1 220px; }

  .st_ok{ color:#17a34a; font-weight:800; }
  .st_nan{ color:#dc2626; font-weight:800; }

  /* ===== Responsive fallback for phones ===== */
  @media (max-width: 820px){
    .wrap{ padding:0 12px; }
    .card{
      border-radius:0;
      padding:12px;
      min-height:100vh;
      box-shadow:0 2px 6px rgba(0,0,0,0.05);
    }

    .tabs{
      gap:8px;
      overflow-x:auto;
      flex-wrap:nowrap;
      -webkit-overflow-scrolling:touch;
    }
    .tabs::-webkit-scrollbar{ display:none; }
    .tabbtn{ padding:0 14px; height:40px; }

    form#f fieldset{
      display:block;
      padding:8px;
      border-radius:8px;
    }
    label{ margin-top:6px; }
    input, textarea, select{ border-radius:8px; }

    #view-info{
      display:block;
    }

    #logbox{
      height: calc(100vh - 290px);
      border-radius:8px;
      padding:10px;
    }
    .log-actions{ flex-wrap:nowrap; }
    .log-actions .btn, .log-actions a.btn{ flex:1 1 auto; }
  }

  /* ===== Very wide screens: a bit more air ===== */
  @media (min-width: 1400px){
    .card{ max-width:1260px; padding:20px 22px 18px; }
    .logo span{ font-size:24px; }
    form#f fieldset{ gap:12px 16px; }
  }
</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head><body><div class="wrap"><div class="card">

<div class="logo">
  <img alt="Marx Krontal Partner" src="/logo.png">
  <span>Rissdetektor</span>
</div>

<div class="topbar">

  <button class="tabbtn active" data-tab="info">
    Information
  </button>

  <div class="top-actions">

    <button class="icon-btn" data-tab="log" title="Logdatei">
      📝
    </button>

    <button class="icon-btn" data-tab="config" title="Konfiguration">
      ⚙
    </button>

  </div>

</div>

<div id="view-config" class="view">
  <form id="f">

    <fieldset><legend>WiFi Access Point</legend>
      <label>AP SSID<input name="ap_ssid" required></label>
      <label>AP Passwort (leer = offen)
        <input name="ap_pass" type="password" autocomplete="new-password">
      </label>
      <div class="note">SSID Default: NB-IoT-RM-&lt;deviceID&gt;</div>
    </fieldset>

    <fieldset><legend>SIM / APN</legend>
      <label>APN<input name="apn" required></label>
      <label>GPRS Benutzer<input name="gprsUser"></label>
      <label>GPRS Passwort<input name="gprsPass" type="password" autocomplete="new-password"></label>
    </fieldset>

    <fieldset><legend>MQTT</legend>
      <label>Server<input name="mqtt_server" required></label>
      <label>Port<input name="mqtt_port" type="number" required min="1" max="65535"></label>
      <label>Benutzer<input name="mqtt_user"></label>
      <label>Passwort<input name="mqtt_pass" type="password" autocomplete="new-password"></label>
      <label>Client-ID<input name="mqtt_client_id" required></label>
      <label>Topic<input name="mqtt_topic" required></label>
      <label>Config-Topic<input name="mqtt_config_topic" required></label>
    </fieldset>

    <fieldset><legend>Intervalle</legend>
      <label>Messinterval (Minuten)
        <input name="messInterval" type="number" required min="1" max="1440">
      </label>
      <label>Sendeintervall (Zyklen)
        <input name="sendInterval" type="number" required min="1" max="100000">
      </label>
      <label style="margin-top:10px; display:flex; align-items:center; gap:8px;">
        <input name="remote_conf_on" type="checkbox" value="1" style="width:auto;">
        Remote-Konfiguration dieser Intervalle via MQTT erlauben
      </label>
      <div class="note">Wenn deaktiviert, MQTT kann messInterval/sendInterval nicht ändern.</div>
    </fieldset>

    <fieldset><legend>Weg Sensor</legend>
      <label>Sensor Skala (mm)
        <input name="sensor_span_mm" type="number" step="0.001" min="0.1" max="100000" required>
      </label>
      <div class="note">Beispiel: 10.0 = 0..10 mm</div>
      <label>Raw 1
        <input name="weg_min_raw" type="number" step="0.1">
      </label>
      <label>Raw 2
        <input name="weg_max_raw" type="number" step="0.1">
      </label>
      <div class="note">Manuelle Kalibrierung des Rohsignals (ADS1115 raw)</div>
      <div class="note">
        Aktueller Raw-Wert:
        <b><span id="i_raw_sig">—</span></b>
      </div>
    </fieldset>

    <fieldset id="fs-actions"><legend>Aktionen</legend>

      <div class="btns actions">
        <button type="button" id="saveReboot">Speichern & Neustart</button>
        <a class="btn outline" href="/api/config?dl=1" download>JSON exportieren</a>
      </div>

      <div class="btns actions" style="margin-top:8px;">
        <button type="button" class="danger" id="factoryReset">Werkseinstellungen</button>
      </div>

      <div class="note" id="status"></div>
    </fieldset>
  </form>

  <fieldset><legend>JSON Import</legend>
    <div class="import-row">
      <label class="import-file">
        Datei (JSON)
        <input type="file" id="file" accept="application/json">
      </label>

      <button type="button" id="importFile" class="btn-import" disabled>
        Importieren
      </button>
    </div>
  </fieldset>

</div>

<div id="view-info" class="view active">
  <div class="pill"><div class="label">Kontroller ID</div><div class="value" id="i_devid">—</div></div>
  <div class="pill"><div class="label">Firmware</div><div class="value" id="i_fw">—</div></div>
  <div class="pill"><div class="label">Batteriespannung</div><div class="value" id="i_batt">—</div></div>

  <!-- NEW: Sensor ports connected -->
  <fieldset>
    <legend>Sensor Status</legend>
    <div class="pill">
      <div class="label">Temperatur Sensor</div>
      <div class="value" id="i_temp_port">—</div>
    </div>
    <div class="pill">
      <div class="label">Wegsensor</div>
      <div class="value" id="i_weg_port">—</div>
    </div>
  </fieldset>

  <fieldset>
    <legend>Wegsensor</legend>
    <div class="pill">
      <div class="label">Distance (mm)</div>
      <div class="value" id="i_ads_ch0">—</div>
    </div>
    <div class="pill">
      <div class="label">Skala (mm)</div>
      <div class="value" id="i_span">—</div>
    </div>
  </fieldset>

  <fieldset>
    <legend>Temperature</legend>
    <div class="pill">
      <div class="label">Temperature, °C</div>
      <div class="value" id="i_temp_c">—</div>
    </div>
  </fieldset>

  <fieldset style="grid-column:1 / -1;">
    <legend>Messwertdiagramm</legend>

    <div style="height:350px;">
      <canvas id="liveChart"></canvas>
  </div>
</fieldset>

</div>

<div id="view-log" class="view">
  <div class="pill">
    <div id="logbox">Laden…</div>
  </div>
  <div class="log-actions">
    <a class="btn outline" id="logDownload" href="/api/log/download" download>Herunterladen</a>
    <a class="btn outline" id="logDownloadOld" href="/api/log/download_old" download>Archiv</a>
    <button type="button" class="btn danger" id="logDelete">Logdateien löschen</button>
  </div>
  <div class="note" id="logNote"></div>
</div>

</div></div>
<script>
let infoTimer = null;
let infoFetching = false;

function show(tab){
  document.querySelectorAll('.tabbtn').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab));
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById('view-'+tab).classList.add('active');

  if (tab === 'info' || tab === 'config')
    startInfoAutoRefresh();
  else
    stopInfoAutoRefresh();

  if (tab === 'log') loadLogChunk(true);
}
document
  .querySelectorAll('.tabbtn, .icon-btn')
  .forEach(b => b.addEventListener('click', () => show(b.dataset.tab)));

function startInfoAutoRefresh(){
  if (infoTimer) return;
  loadInfo();
  infoTimer = setInterval(loadInfo, 500);
}
function stopInfoAutoRefresh(){
  if (!infoTimer) return;
  clearInterval(infoTimer);
  infoTimer = null;
}
document.addEventListener('visibilitychange', ()=>{
  if (document.hidden) stopInfoAutoRefresh();
  else {
    const isInfoActive = document.querySelector('.tabbtn.active')?.dataset.tab === 'info';
    if (isInfoActive) startInfoAutoRefresh();
  }
});

async function loadConfig(){
  const r = await fetch('/api/config');
  const j = await r.json();

  for (const k in j){
    const el = document.querySelector('[name="'+k+'"]');
    if(!el) continue;

    if (el.type === 'checkbox') {
      const v = j[k];

      // accept: true/false, 1/0, "1"/"0", "true"/"false", "on"/"off"
      if (typeof v === 'boolean') el.checked = v;
      else if (typeof v === 'number') el.checked = (v !== 0);
      else if (typeof v === 'string') {
        const s = v.toLowerCase().trim();
        el.checked = (s === '1' || s === 'true' || s === 'on' || s === 'yes');
      } else {
        el.checked = false;
      }
    } else {
      el.value = j[k];
    }
  }
}

async function submitConfig(reboot){
  const fd = new FormData(document.getElementById('f'));
  const params = new URLSearchParams(); fd.forEach((v,k)=>params.append(k,v));

  // IMPORTANT: always send checkbox explicitly (0/1)
  const cb = document.querySelector('[name="remote_conf_on"]');
  if (cb) params.set('remote_conf_on', cb.checked ? '1' : '0');

  if(reboot) params.append('reboot','1');
  const r = await fetch('/api/config', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:params});
  const t = await r.text();
  const st = document.getElementById('status');
  if(r.ok){ st.innerHTML = '<span class="ok">Gespeichert.</span>' + (reboot ? ' Neustart…' : ''); }
  else    { st.innerHTML = '<span class="err">Fehler: </span>' + t; }
}
document.getElementById('f').addEventListener('submit', (e)=>{ e.preventDefault(); submitConfig(false); });
document.getElementById('saveReboot').addEventListener('click', ()=> submitConfig(true));

const fileInput = document.getElementById('file');
const importBtns = [ document.getElementById('importFile') ];
function updateImportButtons(){
  const hasFile = !!(fileInput && fileInput.files && fileInput.files.length > 0);
  importBtns.forEach(b => { if (b) b.disabled = !hasFile; });
}
if (fileInput){ fileInput.addEventListener('change', updateImportButtons); updateImportButtons(); }

async function importJson(text, reboot){
  const st = document.getElementById('status');
  try{
    const r = await fetch('/api/config_json' + (reboot?'?reboot=1':''), {
      method:'POST', headers:{'Content-Type':'application/json'}, body:text
    });
    const t = await r.text();
    if(r.ok){
      st.innerHTML = '<span class="ok">Import abgeschlossen.</span>' + (reboot ? ' Neustart…' : ''); 
      loadConfig();
      if(!reboot && fileInput){ fileInput.value = ''; updateImportButtons(); }
    }else{
      st.innerHTML = '<span class="err">Importfehler: </span>'+t;
    }
  }catch(e){
    st.innerHTML = '<span class="err">Netzwerkfehler: </span>'+e;
  }
}
document.getElementById('importFile').addEventListener('click', async ()=>{
  if(!fileInput || !fileInput.files[0]) return;
  importJson(await fileInput.files[0].text(), false);
});


document.getElementById('factoryReset').addEventListener('click', async ()=>{
  if(!confirm('Alle Einstellungen auf Werkseinstellungen zurücksetzen?')) return;
  const st = document.getElementById('status');
  try{
    const r = await fetch('/api/factory_reset', {method:'POST'});
    const t = await r.text();
    if(r.ok){ st.innerHTML = '<span class="ok">Zurückgesetzt. Seite wird neu geladen…</span>'; setTimeout(loadConfig, 400); }
    else    { st.innerHTML = '<span class="err">Fehler beim Zurücksetzen: </span>'+t; }
  }catch(e){ st.innerHTML = '<span class="err">Netzwerkfehler: </span>'+e; }
});

async function loadInfo(){
  if (infoFetching) return;
  infoFetching = true;
  try{
    const r = await fetch('/api/info', {cache:'no-store'});
    if(!r.ok) return;
    const j = await r.json();
    const set = (id, v)=>{ const el = document.getElementById(id); if(el) el.innerHTML = v; };

    set('i_devid', j.device_id || '—');
    set('i_fw', j.firmware || '—');
    set('i_batt', (typeof j.batt_v === 'number') ? (j.batt_v.toFixed(3) + ' V') : '—');

    // NEW: show "+" if connected
    set('i_temp_port',
    (j.temp_port_connected === true)
      ? '<span class="st_ok">Verbunden</span>'
      : '<span class="st_nan">Nicht verbunden</span>'
    );

    set('i_weg_port',
    (j.weg_port_connected === true)
      ? '<span class="st_ok">Verbunden</span>'
      : '<span class="st_nan">Nicht verbunden</span>'
    );

    set('i_ads_ch0', (typeof j.distance_mm === 'number') ? (j.distance_mm.toFixed(3) + ' mm') : '—');
    set('i_span', (typeof j.sensor_span_mm === 'number') ? (j.sensor_span_mm + ' mm') : '—');
    set('i_raw_sig', (typeof j.raw_sig === 'number') ? j.raw_sig : '—');

    set('i_temp_c', (typeof j.temp_c === 'number') ? (j.temp_c.toFixed(2) + ' °C') : '—');

    const now = new Date();

    const label =
      now.getHours().toString().padStart(2,'0') + ':' +
      now.getMinutes().toString().padStart(2,'0') + ':' +
      now.getSeconds().toString().padStart(2,'0');

    chartLabels.push(label);

    chartWeg.push(
      typeof j.distance_mm === 'number'
        ? Number(j.distance_mm.toFixed(3))
        : null
    );

    chartTemp.push(
      typeof j.temp_c === 'number'
        ? Number(j.temp_c.toFixed(2))
        : null
    );

    // Храним последние 100 точек
    if (chartLabels.length > 100) {
      chartLabels.shift();
      chartWeg.shift();
      chartTemp.shift();
    }

    liveChart.update('none');    

  }catch(e){
  }finally{
    infoFetching = false;
  }
}

let logCursor = 0;
let logEOF = false;
const CHUNK = 32768;
const logBox = document.getElementById('logbox');
const logNote = document.getElementById('logNote');

async function loadLogChunk(reset=false){
  try{
    if(reset){ logCursor = 0; logEOF = false; logBox.textContent = ''; }
    if(logEOF) return;

    const r = await fetch(`/api/log?cursor=${logCursor}&chunk=${CHUNK}`, {cache:'no-store'});
    if(!r.ok){ logNote.textContent = 'Fehler beim Laden der Logdatei'; return; }
    const j = await r.json();

    const prevText = logBox.textContent || '';
    const newWhole = j.text || '';
    let delta = newWhole.substring(0, Math.max(0, newWhole.length - prevText.length));

    if(reset){
      logBox.textContent = newWhole;
      logBox.scrollTop = logBox.scrollHeight;
    }else{
      const oldH = logBox.scrollHeight;
      logBox.textContent = delta + prevText;
      const newH = logBox.scrollHeight;
      logBox.scrollTop = newH - oldH + logBox.scrollTop;
    }

    logCursor = j.cursorNext || logCursor;
    logEOF = !!j.eof;
    logNote.textContent = `Geladen: ${logCursor} / ${j.total} Bytes`;
  }catch(e){
    logNote.textContent = 'Netzwerkfehler beim Laden der Logdatei';
  }
}

logBox.addEventListener('scroll', ()=>{
  const nearTop = (logBox.scrollTop <= 24);
  if(nearTop && !logEOF){
    loadLogChunk(false);
  }
});

document.getElementById('logDelete').addEventListener('click', async ()=>{
  if(!confirm('Logdateien wirklich löschen?')) return;
  try{
    const r = await fetch('/api/log/delete', {method:'POST'});
    const t = await r.text();
    if(r.ok){
      logNote.textContent = 'Gelöscht.';
      loadLogChunk(true);
    }else{
      logNote.textContent = 'Fehler: ' + t;
    }
  }catch(e){
    logNote.textContent = 'Netzwerkfehler: ' + e;
  }
});

const chartLabels = [];
const chartTemp = [];
const chartWeg = [];

const ctx = document.getElementById('liveChart');

const liveChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: chartLabels,
    datasets: [
      {
        label: 'Wegsensor (mm)',
        data: chartWeg,
        borderColor: '#3c57ff',
        backgroundColor: 'rgba(60,87,255,0.15)',
        borderWidth: 3,
        tension: 0.35,
        pointRadius: 0,
        yAxisID: 'y'
      },
      {
        label: 'Temperature (°C)',
        data: chartTemp,
        borderColor: '#ff5b5b',
        backgroundColor: 'rgba(255,91,91,0.15)',
        borderWidth: 3,
        tension: 0.35,
        pointRadius: 0,
        yAxisID: 'y1'
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,

    interaction: {
      mode: 'index',
      intersect: false
    },

    animation: false,

    plugins: {
      legend: {
        position: 'top'
      }
    },

    scales: {
      y: {
        type: 'linear',
        position: 'left',
        title: {
          display: true,
          text: 'mm'
        }
      },

      y1: {
        type: 'linear',
        position: 'right',
        grid: {
          drawOnChartArea: false
        },
        title: {
          display: true,
          text: '°C'
        }
      }
    }
  }
});

show('info');
loadConfig();
//startInfoAutoRefresh();
</script>
</body></html>
)HTML";

/* ====== HTTP handlers ====== */
void handleRoot(){ server.send_P(200, "text/html; charset=utf-8", PAGE_HTML); }

void handleGetConfig(){
  String json = configToJson(cfg);
  if(server.hasArg("dl") && server.arg("dl")=="1"){
    server.sendHeader("Content-Disposition", "attachment; filename=\"config.json\"");
  }
  server.send(200, "application/json; charset=utf-8", json);
}

void handlePostConfig(){
  Config n = cfg;

  // AP
  if(server.hasArg("ap_ssid"))     n.ap_ssid = server.arg("ap_ssid");
  if(server.hasArg("ap_pass"))     n.ap_pass = server.arg("ap_pass");
  if(server.hasArg("ap_channel"))  n.ap_channel = server.arg("ap_channel").toInt();
  if(server.hasArg("ap_max_conn")) n.ap_max_conn = server.arg("ap_max_conn").toInt();

  // SIM/MQTT/Sensor
  if(server.hasArg("apn"))               n.apn = server.arg("apn");
  if(server.hasArg("gprsUser"))          n.gprsUser = server.arg("gprsUser");
  if(server.hasArg("gprsPass"))          n.gprsPass = server.arg("gprsPass");
  if(server.hasArg("mqtt_server"))       n.mqtt_server = server.arg("mqtt_server");
  if(server.hasArg("mqtt_port"))         n.mqtt_port = server.arg("mqtt_port").toInt();
  if(server.hasArg("mqtt_user"))         n.mqtt_user = server.arg("mqtt_user");
  if(server.hasArg("mqtt_pass"))         n.mqtt_pass = server.arg("mqtt_pass");
  if(server.hasArg("mqtt_client_id"))    n.mqtt_client_id = server.arg("mqtt_client_id");
  if(server.hasArg("mqtt_topic"))        n.mqtt_topic = server.arg("mqtt_topic");
  if(server.hasArg("mqtt_config_topic")) n.mqtt_config_topic = server.arg("mqtt_config_topic");
  if(server.hasArg("sensor_span_mm"))    n.sensor_span_mm = server.arg("sensor_span_mm").toFloat();

  if(server.hasArg("weg_min_raw")) n.weg_min_raw = server.arg("weg_min_raw").toFloat();
  if(server.hasArg("weg_max_raw")) n.weg_max_raw = server.arg("weg_max_raw").toFloat();

  // NEW intervals
  if(server.hasArg("messInterval")) n.messInterval_min = server.arg("messInterval").toInt();
  if(server.hasArg("sendInterval")) n.sendInterval_cycles = server.arg("sendInterval").toInt();
  if(server.hasArg("remote_conf_on")) n.remote_conf_on = server.arg("remote_conf_on").toInt();
  
  Serial.printf("remote_conf_on = %d\n", n.remote_conf_on ? 1 : 0);

/*
  // FIX: accept on/1/true and also accept explicit "0"
  if(server.hasArg("remote_conf_on")){
    n.remote_conf_on = argToBool(server.arg("remote_conf_on"));
  } else {
    // if not provided - keep previous (but JS always sends 0/1 anyway)
    n.remote_conf_on = cfg.remote_conf_on;
  }
*/
/*
  // Validate weg_max_raw muss > weg_min_raw sein
  if(n.weg_max_raw <= n.weg_min_raw){
  server.send(400,"text/plain","weg_max_raw muss > weg_min_raw sein");
  return;
  }
*/
  // Validate AP
  if(n.ap_ssid.length()==0){ server.send(400,"text/plain","AP SSID erforderlich"); return; }
  if(n.ap_channel < 1 || n.ap_channel > 13){ server.send(400,"text/plain","Ungültiger AP Kanal (1..13)"); return; }
  if(n.ap_max_conn < 1 || n.ap_max_conn > 8){ server.send(400,"text/plain","Ungültiger AP Max Conn (1..8)"); return; }
  if(n.ap_pass.length()>0 && n.ap_pass.length()<8){ server.send(400,"text/plain","AP Passwort min. 8 Zeichen (oder leer)"); return; }

  // Validate others
  if(n.apn.length()==0){ server.send(400,"text/plain","APN erforderlich"); return; }
  if(n.mqtt_server.length()==0){ server.send(400,"text/plain","MQTT-Server erforderlich"); return; }
  if(n.mqtt_port<=0 || n.mqtt_port>65535){ server.send(400,"text/plain","Ungültiger MQTT-Port"); return; }
  if(n.mqtt_client_id.length()==0){ server.send(400,"text/plain","Client-ID erforderlich"); return; }
  if(n.mqtt_topic.length()==0){ server.send(400,"text/plain","Topic erforderlich"); return; }
  if(n.mqtt_config_topic.length()==0){ server.send(400,"text/plain","Config-Topic erforderlich"); return; }
  if(n.sensor_span_mm < 0.1f || n.sensor_span_mm > 100000.0f){ server.send(400,"text/plain","Ungültige Sensor-Skala"); return; }

  // Validate intervals (min 1)
  if(n.messInterval_min < 1){ server.send(400,"text/plain","Ungültiger messInterval (min 1)"); return; }
  if(n.sendInterval_cycles < 1){ server.send(400,"text/plain","Ungültiger sendInterval (min 1)"); return; }

  if(!saveToNVS(n)){ server.send(500, "text/plain", "NVS-Schreiben fehlgeschlagen"); return; }
  cfg = n;

  // apply instantly
  applyRuntimeIntervalsFromCfgNow();

  server.send(200, "text/plain; charset=utf-8", "OK");

  // apply new AP settings needs reboot
  if(server.hasArg("reboot") && server.arg("reboot")=="1"){ delay(300); ESP.restart(); }
}

void handlePostConfigJson(){
  String body = server.arg("plain");
  if(body.length()==0){ server.send(400,"text/plain","Leerer Body"); return; }

  Config n = cfg;
  String err;
  if(!mergeJsonIntoConfig(body, n, err)){ server.send(400,"text/plain; charset=utf-8", err); return; }

  if(!saveToNVS(n)){ server.send(500, "text/plain", "NVS-Schreiben fehlgeschlagen"); return; }
  cfg = n;

  applyRuntimeIntervalsFromCfgNow();

  server.send(200, "text/plain; charset=utf-8", "Importiert");

  if(server.hasArg("reboot") && server.arg("reboot")=="1"){ delay(300); ESP.restart(); }
}

void handleFactoryReset(){
  preferences.begin("cfg", false);
  preferences.clear();
  preferences.end();
  loadDefaults(cfg);
  saveToNVS(cfg);
  applyRuntimeIntervalsFromCfgNow();
  server.send(200, "text/plain", "Werkseinstellungen wiederhergestellt");
}

/* ====== Logo handler ====== */
void handleLogoPng(){
  server.send_P(200, "image/png", (const char*)logo_png, logo_png_len);
}

/* ====== Info ====== */
void handleInfo(){
  StaticJsonDocument<800> doc;
  float voltage = PMU.getBattVoltage() / 1000.0f;
  doc["batt_v"]          = voltage;
  doc["device_id"]       = deviceID;
  doc["firmware"]        = firmware;
  doc["sensor_span_mm"]  = cfg.sensor_span_mm;
  doc["raw_sig"] = TX2_Resultat;

  // NEW: ports connected flags
  doc["temp_port_connected"] = temp_port_connected;
  doc["weg_port_connected"]  = weg_port_connected;

  if (!isnan(distance)) doc["distance_mm"] = distance;
  else doc["distance_mm"] = nullptr;

  doc["temp_c"] = temp_DS18B20;

  doc["messInterval"]   = messInterval;
  doc["sendInterval"]   = sendInterval;
  doc["remote_conf_on"] = cfg.remote_conf_on;

  String out; serializeJson(doc, out);
  server.send(200, "application/json; charset=utf-8", out);
}

/* ====== LOG: API and downloads ====== */
static const char* LOG_PATH = "/serial.log";
static const char* LOG_OLD  = "/serial.log.1";


String readTailForward(size_t fromEndBytes) {
  size_t sCur = 0, sOld = 0;
  if (SPIFFS.exists(LOG_PATH)) { File f = SPIFFS.open(LOG_PATH, FILE_READ); if (f){ sCur = f.size(); f.close(); } }
  if (SPIFFS.exists(LOG_OLD )) { File f = SPIFFS.open(LOG_OLD , FILE_READ); if (f){ sOld = f.size(); f.close(); } }
  size_t total = sOld + sCur;
  if (total == 0) return "";

  size_t rd = (fromEndBytes >= total) ? total : fromEndBytes;
  size_t start = total - rd;

  String out; out.reserve(rd+16);
  if (start < sOld) {
    size_t takeOld = min(rd, sOld - start);
    File fo = SPIFFS.open(LOG_OLD, FILE_READ);
    if (fo){
      fo.seek(start, SeekSet);
      for (size_t i=0;i<takeOld && fo.available();++i) out += char(fo.read());
      fo.close();
    }
    size_t left = rd - takeOld;
    if (left > 0 && sCur > 0) {
      File fc = SPIFFS.open(LOG_PATH, FILE_READ);
      if (fc){
        fc.seek(0, SeekSet);
        for (size_t i=0;i<left && fc.available();++i) out += char(fc.read());
        fc.close();
      }
    }
  } else {
    size_t offCur = start - sOld;
    File fc = SPIFFS.open(LOG_PATH, FILE_READ);
    if (fc){
      fc.seek(offCur, SeekSet);
      for (size_t i=0;i<rd && fc.available();++i) out += char(fc.read());
      fc.close();
    }
  }

  int firstNL = out.indexOf('\n');
  if (firstNL >= 0) out.remove(0, firstNL + 1);
  return out;
}

void handleLogApi() {
  size_t chunk  = server.hasArg("chunk")  ? (size_t) server.arg("chunk").toInt()  : 32768;
  size_t cursor = server.hasArg("cursor") ? (size_t) server.arg("cursor").toInt() : 0;

  size_t sOld = 0, sCur = 0;
  if (SPIFFS.exists(LOG_OLD)) { File f = SPIFFS.open(LOG_OLD, FILE_READ); sOld = f ? f.size() : 0; if(f) f.close(); }
  if (SPIFFS.exists(LOG_PATH)) { File f = SPIFFS.open(LOG_PATH, FILE_READ); sCur = f ? f.size() : 0; if(f) f.close(); }
  size_t total = sOld + sCur;

  if (total == 0) {
    server.send(200, "application/json", "{\"total\":0,\"cursorNext\":0,\"eof\":true,\"text\":\"\"}");
    return;
  }

  size_t remain = (cursor >= total) ? 0 : (total - cursor);
  size_t take   = (chunk >= remain) ? remain : chunk;

  size_t wantFromEnd = cursor + take;
  String text = readTailForward(wantFromEnd);

  size_t cursorNext = cursor + take;
  bool eof = (cursorNext >= total);

  String body;
  body.reserve(text.length() + 128);
  body += "{\"total\":";
  body += String(total);
  body += ",\"cursorNext\":";
  body += String(cursorNext);
  body += ",\"eof\":";
  body += (eof ? "true" : "false");
  body += ",\"text\":\"";
  for (size_t i=0;i<text.length();++i){
    char c = text[i];
    if (c=='\\' || c=='\"') { body += '\\'; body += c; }
    else if (c=='\n') body += "\\n";
    else if (c=='\r') { }
    else body += c;
  }
  body += "\"}";
  server.send(200, "application/json; charset=utf-8", body);
}

void handleLogDownload() {
  if (!SPIFFS.exists(LOG_PATH)) { server.send(404, "text/plain", "serial.log not found"); return; }
  server.sendHeader("Content-Disposition", "attachment; filename=\"serial.log\"");
  File f = SPIFFS.open(LOG_PATH, FILE_READ);
  server.streamFile(f, "text/plain");
  f.close();
}

void handleLogDownloadOld() {
  if (!SPIFFS.exists(LOG_OLD)) { server.send(404, "text/plain", "serial.log.1 not found"); return; }
  server.sendHeader("Content-Disposition", "attachment; filename=\"serial.log.1\"");
  File f = SPIFFS.open(LOG_OLD, FILE_READ);
  server.streamFile(f, "text/plain");
  f.close();
}

void handleLogDelete(){
  bool ok1 = true, ok2 = true;
  if (SPIFFS.exists(LOG_PATH)) ok1 = SPIFFS.remove(LOG_PATH);
  if (SPIFFS.exists(LOG_OLD))  ok2 = SPIFFS.remove(LOG_OLD);
  if (ok1 && ok2) server.send(200, "text/plain", "OK");
  else            server.send(500, "text/plain", "Delete failed");
}

/* ====== WiFi / Server ====== */
String formatIp(IPAddress ip){
  char buf[24];
  snprintf(buf, sizeof(buf), "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
  return String(buf);
}

void setup_wifi() {
  boot_ms = 0;

  loadFromNVS(cfg);
  applyRuntimeIntervalsFromCfgNow();

  IPAddress apIP(192,168,4,1), gateway(192,168,4,1), mask(255,255,255,0);
  WiFi.softAPConfig(apIP, gateway, mask);
  WiFi.mode(WIFI_AP);

  bool ok = WiFi.softAP(
    cfg.ap_ssid.c_str(),
    (cfg.ap_pass.length() ? cfg.ap_pass.c_str() : nullptr),
    cfg.ap_channel,
    false,
    cfg.ap_max_conn
  );

  SerialMon.println(ok ? "[OK] AP gestartet" : "[ERR] AP fehlgeschlagen");
  SerialMon.print("AP SSID: "); SerialMon.println(cfg.ap_ssid);
  SerialMon.print("AP IP  : "); SerialMon.println(formatIp(WiFi.softAPIP()));

  server.on("/", HTTP_GET, handleRoot);
  server.on("/logo.png", HTTP_GET, handleLogoPng);
  server.on("/api/config", HTTP_GET, handleGetConfig);
  server.on("/api/config", HTTP_POST, handlePostConfig);
  server.on("/api/config_json", HTTP_POST, handlePostConfigJson);
  server.on("/api/factory_reset", HTTP_POST, handleFactoryReset);
  server.on("/api/info", HTTP_GET, handleInfo);

  server.on("/api/log", HTTP_GET, handleLogApi);
  server.on("/api/log/download", HTTP_GET, handleLogDownload);
  server.on("/api/log/download_old", HTTP_GET, handleLogDownloadOld);
  server.on("/api/log/delete", HTTP_POST, handleLogDelete);

  server.onNotFound([](){ server.send(404, "text/plain; charset=utf-8", "Nicht gefunden"); });

  server.begin();
  SerialMon.println("HTTP-Server gestartet");

  boot_ms = millis();
}