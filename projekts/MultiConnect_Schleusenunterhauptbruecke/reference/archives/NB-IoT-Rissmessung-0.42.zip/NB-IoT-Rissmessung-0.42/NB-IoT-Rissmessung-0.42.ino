#include <Arduino.h>
String firmware = "0.42";

#define SerialAT  Serial1
#include "utilities.h"
#include <SD_MMC.h>
#include <FS.h>
#include <TimeLib.h>
#include "SPIFFS.h"
#include <log_file.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

//DS18B20---------------------------------------
#define DS18B20_POWER 16
#define DS18B20_DATA 17
#include <OneWire.h>
#include <DallasTemperature.h>

OneWire oneWire(DS18B20_DATA);
DallasTemperature DS18B20(&oneWire);
float temp_DS18B20 = 0.00;

// ====== NEW: sensor port detect pins ======
#define TEMP_PORT_IO 18   // Temperatur Sensor Port (IO18)
#define WEG_PORT_IO  12   // Weg Sensor Port (IO12)
bool temp_port_connected = false;
bool weg_port_connected  = false;
// ==========================================

//ADS1115---------------------------------------
#include <Wire.h>
#include <Adafruit_ADS1X15.h>
TwoWire ADS1115_I2C_2 = TwoWire(1);
Adafruit_ADS1115 ads_1115;

#define ADS_PWR_ADS1115 21
#define SDA_ADS1115 36
#define SCL_ADS1115 37
#define ADDR_ADS1115 0x48
//-----------------------------------------------

#define TX2_POWER 14
#define TX2_DATA 13
int16_t TX2_Resultat = 0;     // rawSig

#define TINY_GSM_MODEM_SIM7080
#define TINY_GSM_RX_BUFFER 1024
#define TINY_GSM_DEBUG SerialMon
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
Preferences preferences;

int messInterval = 1;    // minutes (runtime)  <-- ONLY from cfg
int sendInterval = 1;    // cycles  (runtime)  <-- ONLY from cfg
int messZyklus;
time_t localUnixTime;
time_t unixTime;
float voltage;
String deviceID;

File file;

// SIM-Karte defaults (factory)
//const char apn[] = "internet.m2mportal.de";
const char apn[] = "iotsim.melita.io";

const char gprsUser[] = "";
const char gprsPass[] = "";

// MQTT defaults (factory)
const char* mqtt_server = "mqtt.marxkrontal.com";
const int   mqtt_port = 1883;
const char* mqtt_user = "funksystemiot";
const char* mqtt_pass = "4bx7aijN_mb?znh2T`T\"";

const char* mqtt_client_id = "1081ACA0ED30";
const char* mqtt_topic = "test/funksystemiot/lowenergy_sensors/1081ACA0ED30";
const char* mqtt_config_topic = "test-monitoring/config/Box2";

TinyGsm modem(SerialAT);
TinyGsmClient gsmClient(modem);
PubSubClient mqtt(gsmClient);

#define XPOWERS_CHIP_AXP2101
#include "XPowersLib.h"
XPowersPMU PMU;

int _year, _month, _day, _hour, _minute, _second;
float _tzone;
String netTime = "";

unsigned long startMillis;
const float SLEEP_K = 1.0;   // поправочный коэф таймера

bool connect_m = false;

//Konfiguration modus
#define PIN_CONFIGMOD 1
#include <WiFi.h>
#include <WebServer.h>
WebServer server(80);
bool wifi_started = false;

TaskHandle_t webTaskHandle = nullptr;

void webTask(void *pvParameters)
{
    while (true)
    {
        server.handleClient();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

/* ====== Modell ====== */
struct Config {
  // SIM / MQTT
  String apn, gprsUser, gprsPass;
  String mqtt_server, mqtt_user, mqtt_pass, mqtt_client_id, mqtt_topic, mqtt_config_topic;
  int    mqtt_port;

  // Sensor
  float  sensor_span_mm;
  float  weg_min_raw;   // NEW: raw minimum (calibration)
  float  weg_max_raw;   // NEW: raw maximum (calibration)

  // WiFi AP
  String ap_ssid;
  String ap_pass;
  int    ap_channel;
  int    ap_max_conn;

  // NEW: intervals + remote-control switch
  int    messInterval_min;        // minutes
  int    sendInterval_cycles;     // cycles
  int    remote_conf_on;          // if false => ignore MQTT updates for those two
} cfg;

unsigned long boot_ms = 0;
#include <WiFi_main.h>

// distance в мм (скалированное)
float distance = NAN;

int state = 0; // 0 - Arbeitsmodus  1 - Configmodus

// ====== ONLY ONE IMPORTANT PARAM: CSQ (NEW) ======
int csqValue = -1;   // 0..31 typically; -1 means "unknown/not read yet"
// =================================================


// ------------------ helpers ------------------
static int splitCSV(const String& s, char delim, String* out, int maxParts) {
  int count = 0;
  int start = 0;
  int len = s.length();
  for (int i = 0; i <= len && count < maxParts; i++) {
    if (i == len || s[i] == delim) {
      out[count++] = s.substring(start, i);
      start = i + 1;
    }
  }
  return count;
}
// --------------------------------------------

void SaveDateSPIFFS();
bool initADS1115();
int16_t readAverageCh(uint8_t ch, uint8_t samples);
uint16_t Measure_ADS1115();
void Measure_DS18B20();
bool initModem();
void initPOWER();
bool connectMQTT();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void shutdownPOWER();
time_t convertToUnixTime(int yr, int mon, int day, int hr, int min, int sec);
String unixToIsoUtc(time_t utc);
void NB_IoT_status();

int16_t readMedianCh(uint8_t ch)
{
    const uint8_t N = 15;
    int16_t values[N];

    for (uint8_t i = 0; i < N; i++) {
        values[i] = ads_1115.readADC_SingleEnded(ch);
        delay(5);
    }

    // Сортировка
    for (uint8_t i = 0; i < N - 1; i++) {
        for (uint8_t j = i + 1; j < N; j++) {
            if (values[j] < values[i]) {
                int16_t tmp = values[i];
                values[i] = values[j];
                values[j] = tmp;
            }
        }
    }

    // Медиана
    return values[N / 2];
}

bool removeFirstLineFromFile()
{
    File src = SPIFFS.open("/data.csv", FILE_READ);
    if (!src) return false;

    File tmp = SPIFFS.open("/data.tmp", FILE_WRITE);
    if (!tmp) {
        src.close();
        return false;
    }

    bool firstLine = true;

    while (src.available()) {
        String line = src.readStringUntil('\n');

        if (firstLine) {
            firstLine = false;
            continue; // пропускаем первую строку
        }

        tmp.println(line);
    }

    src.close();
    tmp.close();

    SPIFFS.remove("/data.csv");
    SPIFFS.rename("/data.tmp", "/data.csv");

    return true;
}

static void applyIntervalsFromCfg() {
  // requirement: if keys are missing => defaults must be 1 and 1
  if (cfg.messInterval_min < 1) cfg.messInterval_min = 1;
  if (cfg.sendInterval_cycles < 1) cfg.sendInterval_cycles = 1;
  messInterval = cfg.messInterval_min;
  sendInterval = cfg.sendInterval_cycles;
}

void setup()
{
  pinMode(PIN_CONFIGMOD, INPUT_PULLDOWN);

  // ====== NEW: detect pins as INPUT_PULLUP ======
  pinMode(TEMP_PORT_IO, INPUT_PULLUP);
  pinMode(WEG_PORT_IO,  INPUT_PULLUP);
  // ============================================

  startMillis = millis();

  if (!SPIFFS.begin(true)) {
    Serial.begin(115200);
    Serial.println("Fehler beim Mounten von SPIFFS");
    return;
  }

  SerialMon.attachFS(&SPIFFS, "/serial.log");
  SerialMon.setMaxSize(256 * 1024);
  SerialMon.begin(115200);

  // deviceID before setup_wifi() so default SSID is NB-IoT-RM-<deviceID>
  deviceID = makeDeviceId();

  // apply intervals from cfg to runtime
  loadFromNVS(cfg); 
  applyIntervalsFromCfg();

  initPOWER();

  // MQTT use cfg values (not factory constants)
  mqtt.setServer(cfg.mqtt_server.c_str(), cfg.mqtt_port);
  mqtt.setCallback(mqttCallback);
  mqtt.setBufferSize(512); 
  mqtt.setKeepAlive(60);
  mqtt.setSocketTimeout(20);
  
  esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();

  // Namespace "config" is ONLY runtime-state (messZyklus/unixT/csq)
  preferences.begin("config", false);

  if (wakeup_reason == ESP_SLEEP_WAKEUP_UNDEFINED) {
    preferences.putInt("messZyk", 0);
  }
  messZyklus = preferences.getInt("messZyk", 0);

  // Restore last CSQ from NVS
  if (preferences.isKey("csq")) {
    csqValue = preferences.getInt("csq", -1);
  }

  preferences.end();

  SerialMon.println("Runtime (NVS 'config'):");
  SerialMon.printf("messZyklus: %d\n", messZyklus);
  SerialMon.printf("CSQ restore: %d\n", csqValue);

  SerialMon.println("CFG (NVS 'cfg'):");
  SerialMon.printf("messInterval: %d\n", messInterval);
  SerialMon.printf("sendInterval: %d\n", sendInterval);
  SerialMon.printf("remote_conf_on: %s\n", cfg.remote_conf_on ? "true" : "false");

  pinMode(ADS_PWR_ADS1115, OUTPUT);
  pinMode(TX2_POWER, OUTPUT);
  digitalWrite(TX2_POWER, LOW);

  pinMode(DS18B20_POWER, OUTPUT);
  digitalWrite(DS18B20_POWER, HIGH);
  delay(100);
  DS18B20.begin();
  SerialMon.println("DS18B20 initialized");
  DS18B20.setResolution(10);
  digitalWrite(DS18B20_POWER, LOW);
}

void loop() {

  unsigned long activeTimeMs;
  unsigned long targetMs;
  long syncTimeMs;

  // ====== NEW: update port connected flags ======
  temp_port_connected = (digitalRead(TEMP_PORT_IO) == LOW);
  weg_port_connected  = (digitalRead(WEG_PORT_IO)  == LOW);
  // ============================================

  voltage = PMU.getBattVoltage() / 1000.0;
  SerialMon.printf("Batteriespannung: %.3f V\n", voltage);

  // rawSig + distance(mm)
  TX2_Resultat = (int16_t)Measure_ADS1115();
  Measure_DS18B20();

  state = digitalRead(PIN_CONFIGMOD);
  //if (state == HIGH) {
  //  goto end_m;
  //}
  
  if (state == HIGH && !wifi_started) {
      SerialMon.println("CONFIG MODE: Starting WiFi AP...");
      setup_wifi();

      xTaskCreatePinnedToCore(
          webTask,
          "WebTask",
          8192,
          NULL,
          1,
          &webTaskHandle,
          0
      );

      wifi_started = true;
  }

  if (state == HIGH) {
    goto end_m;
  }

  if (state == LOW && wifi_started) {
      SerialMon.println("CONFIG MODE OFF: Stopping WiFi...");

      if (webTaskHandle != nullptr) {
          vTaskDelete(webTaskHandle);
          webTaskHandle = nullptr;
      }

      WiFi.softAPdisconnect(true);
      WiFi.mode(WIFI_OFF);

      wifi_started = false;
  }

  SerialMon.println("Zyklus: " + String(messZyklus) + " Datenerfassung");

  if (messZyklus == 0 || messZyklus >= sendInterval) {

    powerOnModem();

    if (!initModem()) {
        powerOffModem();
        goto m_init;
    }
    if (!connectMQTT()) goto m_init;

    if (modem.getNetworkTime(&_year, &_month, &_day, &_hour, &_minute, &_second, &_tzone)) {
      char isoTime[30];
      sprintf(isoTime, "%04d-%02d-%02dT%02d:%02d:%02d.000Z", _year, _month, _day, _hour, _minute, _second);
      netTime = String(isoTime);

      localUnixTime = convertToUnixTime(_year, _month, _day, _hour, _minute, _second);
      unixTime = localUnixTime - (time_t)(_tzone * 3600);

      preferences.begin("config", false);
      preferences.putInt("unixT", (int)unixTime);
      preferences.end();

      SerialMon.printf("Netzwerkzeit: %s | UNIX: %ld\n", isoTime, (long)unixTime);
    } else {
      SerialMon.println("Abrufen der Netzwerkzeit fehlgeschlagen!");
    }

    SaveDateSPIFFS();

    while (SPIFFS.exists("/data.csv")) {

      file = SPIFFS.open("/data.csv", FILE_READ);
      if (!file) {
        SerialMon.println("Fehler beim Öffnen der Datei zum Lesen");
        break;
      }

      if (!file.available()) {
        file.close();
        SPIFFS.remove("/data.csv");
        SerialMon.println("Datei data.csv ist leer und wurde gelöscht");
        break;
      }

      String line = file.readStringUntil('\n');
      file.close();

      line.trim();

      if (line.length() == 0) {
        removeFirstLineFromFile();
        continue;
      }

      SerialMon.println("Sende Zeile " + line);

      String parts[6];
      int n = splitCSV(line, ',', parts, 6);

      time_t ts = (time_t)parts[0].toInt();
      netTime = unixToIsoUtc(ts);

      int16_t rawSigFromFile   = (n >= 2) ? (int16_t)parts[1].toInt() : 0;
      float   voltageFromFile  = (n >= 3) ? parts[2].toFloat() : NAN;
      float   tempFromFile     = (n >= 4) ? parts[3].toFloat() : NAN;
      float   distFromFile     = (n >= 5) ? parts[4].toFloat() : NAN;
      int     csqFromFile      = (n >= 6) ? parts[5].toInt() : csqValue;

      TX2_Resultat  = rawSigFromFile;
      voltage       = voltageFromFile;
      temp_DS18B20  = tempFromFile;
      distance      = distFromFile;
      csqValue      = csqFromFile;

      String payload = "{\"Timestamp\":\"" + netTime + "\"" +
        ", \"Batteriespannung\": " + String(voltage, 2) +
        ", \"RissSensor_raw\": " + String(TX2_Resultat) +
        ", \"RissSensor_mm\": " + (isnan(distance) ? String("null") : String(distance, 4)) +
        ", \"DS18B20_Temperature\": " + String(temp_DS18B20, 2) +
        ", \"CSQ\": " + String(csqValue) +
        ", \"ControllerID\":\"" + deviceID + "\"" +
        ", \"messInterval\":\"" + String(messInterval) + "\"" +
        ", \"sendInterval\":\"" + String(sendInterval) + "\"" +
        "}";

      bool sent = false;

      for (int attempt = 1; attempt <= 3; attempt++) {

        if (!mqtt.connected()) {
          SerialMon.println("MQTT disconnected before publish.");

          if (!reconnectMQTT()) {
            delay(1000);
            continue;
          }
        }

        SerialMon.printf("Publish attempt %d\n", attempt);

        if (mqtt.publish(cfg.mqtt_topic.c_str(), payload.c_str(), false)) {
          SerialMon.println("Daten an MQTT-Broker gesendet:");
          SerialMon.println(payload);

          unsigned long t = millis();
          while (millis() - t < 300) {
            mqtt.loop();
            delay(10);
          }

          sent = true;
          break;
        }

        SerialMon.printf("MQTT publish failed, state=%d connected=%d\n",
                        mqtt.state(), mqtt.connected());

        mqtt.disconnect();
        delay(1000);
      }

      if (sent) {
        if (removeFirstLineFromFile()) {
          SerialMon.println("Gesendete Zeile aus data.csv gelöscht");
        } else {
          SerialMon.println("Fehler beim Löschen der gesendeten Zeile");
          goto m_init;
        }

        unsigned long waitStart = millis();
        while (millis() - waitStart < 300) {
          mqtt.loop();
          delay(10);
        }

      } else {
        SerialMon.println("Zeile konnte nach 3 Versuchen nicht gesendet werden.");
        goto m_init;
      }
    }

    unsigned long start = millis();
    while (millis() - start < 2000) {
      mqtt.loop();
      delay(10);
    }
    mqtt.disconnect();
    powerOffModem();

  } else {

  m_init:
      preferences.begin("config", false);
      unixTime = (time_t)preferences.getInt("unixT", 0);
      unixTime = unixTime + (messInterval * 60);
      preferences.putInt("unixT", (int)unixTime);
      preferences.end();

      SaveDateSPIFFS();
  }

  if (messZyklus >= sendInterval) {
    if (connect_m == true) messZyklus = 1;
  } else {
    messZyklus = messZyklus + 1;
  }

  preferences.begin("config", false);
  preferences.putInt("messZyk", messZyklus);
  preferences.end();

  shutdownPOWER();

  activeTimeMs = millis() - startMillis;
  SerialMon.printf("Betrieb vor dem Schlaf: %.2f Sekunden\n", activeTimeMs / 1000.0);

  targetMs = (unsigned long)(messInterval * 60UL * 1000UL * SLEEP_K);
  syncTimeMs = (long)targetMs - (long)activeTimeMs;

  if (syncTimeMs > 0) {
    esp_sleep_enable_timer_wakeup((uint64_t)syncTimeMs * 1000ULL);
    SerialMon.println("Gehe in Deep Sleep für " + String(syncTimeMs / 1000.0, 2) + " Sekunden...");
    SerialMon.flush();
    SerialMon.closeLog();
    Serial.end(); 
    Serial.end();

    esp_deep_sleep_start();
  } else {
    SerialMon.println("Kein Deep Sleep (syncTimeMs <= 0), NEUSTART...");
    SerialMon.flush();
    SerialMon.closeLog();
    esp_restart();
  }

end_m:
  ;
}

void SaveDateSPIFFS() {
  // CSV: unix,rawSig,voltage,temp,distance_mm,csq
  File f = SPIFFS.open("/data.csv", FILE_APPEND);
  if (f) {
    String dataLine =
      String(unixTime) + "," +
      String(TX2_Resultat) + "," +
      String(voltage, 2) + "," +
      String(temp_DS18B20, 2) + "," +
      (isnan(distance) ? String("nan") : String(distance, 4)) + "," +
      String(csqValue) +
      "\n";
    f.print(dataLine);
    f.close();
    SerialMon.println("Daten wurden in data.csv gespeichert");
  } else {
    SerialMon.println("Fehler beim Öffnen der Datei zum Schreiben");
  }
}

bool initADS1115() {
  ADS1115_I2C_2.begin(SDA_ADS1115, SCL_ADS1115, 400000);
  ads_1115.setGain(GAIN_TWOTHIRDS);
  ads_1115.setDataRate(RATE_ADS1115_128SPS);

  for (int i = 0; i < 5; i++) {
    if (ads_1115.begin(ADDR_ADS1115, &ADS1115_I2C_2)) return true;
    delay(20);
  }
  return false;
}

int16_t readAverageCh(uint8_t ch, uint8_t samples) {
  long sum = 0;
  for (uint8_t i = 0; i < samples; i++) {
    sum += ads_1115.readADC_SingleEnded(ch);
    delay(5);
  }
  long avg = sum / samples;
  if (avg < 0) avg = 0;
  if (avg > 32767) avg = 32767;
  return (int16_t)avg;
}

uint16_t Measure_ADS1115() {

  digitalWrite(TX2_POWER, HIGH);
  digitalWrite(ADS_PWR_ADS1115, HIGH);
  delay(50);

  if (!initADS1115()) {
    SerialMon.println("ADS1115 nicht gefunden!");
    digitalWrite(TX2_POWER, LOW);
    digitalWrite(ADS_PWR_ADS1115, LOW);
    distance = NAN;
    return 0;
  }

  //int16_t rawRef = readAverageCh(1, 8);  // CH1 = Vref
  //int16_t rawSig = readAverageCh(0, 8);  // CH0 = sensor signal
  int16_t rawRef = readMedianCh(1);   // опорное напряжение
  int16_t rawSig = readMedianCh(0);   // сигнал датчика

  if (rawRef < 10) {   // защита от деления на 0 / плохой контакт
    SerialMon.printf("Vref zu klein/kein Kontakt (rawRef=%d)\n", rawRef);
    distance = NAN;
    digitalWrite(TX2_POWER, LOW);
    digitalWrite(ADS_PWR_ADS1115, LOW);
    return (uint16_t)rawSig;
  }

  float span = cfg.sensor_span_mm;
  if (span < 0.1f || span > 100000.0f)
    span = 10.0f;

  // =====================================================
  // Компенсация питания (через rawRef)
  // =====================================================

  // Приведение сигнала к идеальному диапазону 0..32767
  //float rawSigComp = ((float)rawSig / (float)rawRef) * 32767.0f;

  // =====================================================
  // Ручная калибровка Min / Max
  // =====================================================

  float rawMin = cfg.weg_min_raw;
  float rawMax = cfg.weg_max_raw;

  float norm;

  if (rawMax == rawMin) {
    rawMin = 0.0f;
    rawMax = 32767.0f;
  }

  if (rawMax > rawMin) {
    norm = (rawSig - rawMin) / (rawMax - rawMin);
  } else {
    norm = (rawMin - rawSig) / (rawMin - rawMax);
  }

  if (norm < 0.0f) norm = 0.0f;
  if (norm > 1.0f) norm = 1.0f;

  // =====================================================
  // Перевод в мм
  // =====================================================

  distance = norm * span;

  // =====================================================
  // Debug Output
  // =====================================================

  const float FS = 6.144f;
  float vRef = rawRef * (FS / 32768.0f);
  float vSig = rawSig * (FS / 32768.0f);

  SerialMon.printf(
    "REF: %d (%.4f V) | SIG: %d (%.4f V) | norm=%.4f | dist=%.4f mm\n",
    rawRef, vRef,
    rawSig, vSig,
    norm,
    distance
  );

  digitalWrite(TX2_POWER, LOW);
  digitalWrite(ADS_PWR_ADS1115, LOW);

  return (uint16_t)rawSig;
}

void Measure_DS18B20() {
  digitalWrite(DS18B20_POWER, HIGH);
  delay(100);
  DS18B20.requestTemperatures();
  delay(200);
  temp_DS18B20 = DS18B20.getTempCByIndex(0);

  SerialMon.printf("Temperatur DS18B20: %.2f °C\n", temp_DS18B20);
  digitalWrite(DS18B20_POWER, LOW);
}

bool initModem()
{
  SerialMon.println("Initialisiere Modem...");

  SerialAT.begin(115200, SERIAL_8N1, BOARD_MODEM_RXD_PIN, BOARD_MODEM_TXD_PIN);
  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);

  unsigned long startWait = millis();
  const unsigned long maxWait = 30UL * 1000UL;
  int retry = 0;

  while (!modem.testAT(1000)) {
    SerialMon.print(".");

    if (retry++ > 15) {
      SerialMon.println("\nModem wird neu gestartet...");
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
      delay(100);
      digitalWrite(BOARD_MODEM_PWR_PIN, HIGH);
      delay(1000);
      digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
      retry = 0;
    }

    if (millis() - startWait > maxWait) {
      SerialMon.println("\nModem antwortet nicht, Zeitüberschreitung!");
      break;
    }
  }

  if (modem.testAT(1000)) {
    SerialMon.println("Modem betriebsbereit.");
  } else {
    SerialMon.println("Fehler: Modem antwortet nicht.");
    return false;
  }

  // CNMP/CMNB
  String cnmp, cmnb;

  modem.sendAT("+CNMP?");
  if (modem.waitResponse(1000, cnmp) == 1 && cnmp.indexOf("+CNMP: 38") != -1) {
    SerialMon.println("CNMP bereits auf 38 gesetzt");
  } else {
    modem.sendAT("+CNMP=38");
  }

  modem.sendAT("+CMNB?");
  if (modem.waitResponse(1000, cmnb) == 1 && cmnb.indexOf("+CMNB: 1") != -1) {
    SerialMon.println("CMNB bereits auf 1 gesetzt");
  } else {
    modem.sendAT("+CMNB=1");
  }

  if (cnmp.indexOf("+CNMP: 38") == -1 || cmnb.indexOf("+CMNB: 1") == -1) {
    SerialMon.println("Modem wird neu gestartet, um Netzwerkeinstellungen anzuwenden...");
    modem.restart();
    delay(10000);
  }

  SerialMon.println(modem.getOperator());
  SerialMon.println(modem.getSignalQuality());
  SerialMon.println(modem.isNetworkConnected() ? "Verbunden" : "Nicht verbunden");

  if (!modem.gprsConnect(cfg.apn.c_str(), cfg.gprsUser.c_str(), cfg.gprsPass.c_str())) {
    SerialMon.println("Verbindung mit dem NB-IoT-Netzwerk fehlgeschlagen.");
    connect_m = false;
    return false;
  }

  SerialMon.println("Mit dem NB-IoT-Netzwerk verbunden.");

  // Read & store ONLY CSQ
  NB_IoT_status();

  connect_m = true;
  return true;
}

void initPOWER()
{
  if (!PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
    SerialMon.println("Fehler bei der Initialisierung der Stromversorgung.");
    ESP.restart();
  }

  PMU.setChargeTargetVoltage(XPOWERS_AXP2101_CHG_VOL_4V2);
  PMU.setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);

  PMU.enableTemperatureMeasure(); 
  PMU.enableBattDetection(); 
  PMU.enableVbusVoltageMeasure(); 
  PMU.enableBattVoltageMeasure(); 
  PMU.enableSystemVoltageMeasure();

  PMU.disableDC2();
  PMU.disableDC4();
  PMU.disableDC5();
  PMU.disableALDO1();
  PMU.disableALDO2();
  PMU.disableALDO3();
  PMU.disableALDO4();
  PMU.disableBLDO2();
  PMU.disableCPUSLDO();
  PMU.disableDLDO1();
  PMU.disableDLDO2();

  if (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_UNDEFINED ) {
    PMU.disableDC3();
    delay(200);
  }

  PMU.setBLDO1Voltage(3300);
  PMU.enableBLDO1();

  PMU.setDC3Voltage(3000);
  //PMU.enableDC3();

  PMU.setBLDO2Voltage(3300);
  PMU.enableBLDO2();

  PMU.setALDO3Voltage(3300);
  PMU.enableALDO3();

  PMU.disableTSPinMeasure();
}

void powerOnModem()
{
  SerialMon.println("Power ON modem");

  PMU.enableDC3();               // питание модема
  delay(200);

  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);
  digitalWrite(BOARD_MODEM_PWR_PIN, HIGH);
  delay(500);
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);

  delay(2000); // дать модему стартовать
}

void powerOffModem()
{
  SerialMon.println("Power OFF modem");

  modem.poweroff();
  delay(1000);

  PMU.disableDC3();   // полностью обесточить модем
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
}

bool connectMQTT()
{
  SerialMon.println("Verbinde mit MQTT-Broker...");
  const int maxAttempts = 5;
  int attempt = 0;

  while (!mqtt.connected() && attempt < maxAttempts) {
        attempt++;
        SerialMon.print("Attempt ");
        SerialMon.print(attempt);
        SerialMon.println(" to connect to MQTT broker...");

        if (mqtt.connect(cfg.mqtt_client_id.c_str(), cfg.mqtt_user.c_str(), cfg.mqtt_pass.c_str())) {
          mqtt.subscribe(cfg.mqtt_config_topic.c_str());
          SerialMon.println("Mit MQTT-Broker verbunden!");
          connect_m = true;
          return true;
        } else {
          SerialMon.print("Fehler bei der MQTT-Broker-Verbindung, Code=");
          SerialMon.println(mqtt.state());
          delay(2000); // задержка между попытками
          
        }
  }
  SerialMon.println("Failed to connect to MQTT broker after 5 attempts.");
  connect_m = false;
  return false;
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  char message[length + 1];
  memcpy(message, payload, length);
  message[length] = '\0';

  SerialMon.printf("MQTT: %s => %s\n", topic, message);

  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, message)) {
    SerialMon.println("JSON-Fehler");
    return;
  }

  // Remote configuration of intervals can be disabled in Web UI
  if (!cfg.remote_conf_on) {
    if (doc.containsKey("sendInterval") || doc.containsKey("messInterval")) {
      SerialMon.println("Remote intervals disabled: ignoring messInterval/sendInterval from MQTT");
    }
    return;
  }

  bool changed = false;

  if (doc.containsKey("sendInterval")) {
    int v = doc["sendInterval"].as<int>();
    if (v < 1) v = 1;
    if (v != cfg.sendInterval_cycles) {
      cfg.sendInterval_cycles = v;
      sendInterval = v;
      changed = true;
    }
  }
  if (doc.containsKey("messInterval")) {
    int v = doc["messInterval"].as<int>();
    if (v < 1) v = 1;
    if (v != cfg.messInterval_min) {
      cfg.messInterval_min = v;
      messInterval = v;
      changed = true;
    }
  }

  if (changed) {
    SerialMon.printf("Intervals updated via MQTT: messInterval=%d sendInterval=%d\n", messInterval, sendInterval);
    saveToNVS(cfg);   // single write, only when actually changed
  }
}

bool reconnectMQTT()
{
  if (mqtt.connected()) return true;

  SerialMon.println("MQTT getrennt. Versuche neue Verbindung...");

  mqtt.disconnect();
  delay(1000);

  if (connectMQTT()) {
    SerialMon.println("MQTT erneut verbunden.");
    return true;
  }

  SerialMon.println("MQTT reconnect fehlgeschlagen.");
  return false;
}

void shutdownPOWER()
{
  //powerOffModem();

  PMU.disableTemperatureMeasure(); 
  PMU.disableBattDetection(); 
  PMU.disableVbusVoltageMeasure(); 
  PMU.disableBattVoltageMeasure(); 
  PMU.disableSystemVoltageMeasure();

  PMU.disableDC2();
  PMU.disableDC4();
  PMU.disableDC5();

  PMU.disableALDO1();
  PMU.disableALDO2();
  PMU.disableALDO3();
  PMU.disableALDO4();

  PMU.disableBLDO1();
  PMU.disableBLDO2();
  PMU.disableCPUSLDO();
  PMU.disableDLDO1();
  PMU.disableDLDO2();

  SerialAT.end(); 
  SerialAT.end();

  PMU.clearIrqStatus();

  PMU.setChargingLedMode(XPOWERS_CHG_LED_OFF);

  Wire.end();
  Wire1.end();

  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);

  gpio_reset_pin(GPIO_NUM_1);
  gpio_reset_pin(GPIO_NUM_3);
  gpio_reset_pin(GPIO_NUM_4);
  gpio_reset_pin(GPIO_NUM_5);
  gpio_reset_pin(GPIO_NUM_7);
  gpio_reset_pin(GPIO_NUM_12);
  gpio_reset_pin(GPIO_NUM_13);
  gpio_reset_pin(GPIO_NUM_14);
  gpio_reset_pin(GPIO_NUM_15);
  gpio_reset_pin(GPIO_NUM_16);
  gpio_reset_pin(GPIO_NUM_17);
  gpio_reset_pin(GPIO_NUM_18);
  gpio_reset_pin(GPIO_NUM_21);
  gpio_reset_pin(GPIO_NUM_36);
  gpio_reset_pin(GPIO_NUM_37);
  gpio_reset_pin(GPIO_NUM_41);
  gpio_reset_pin(GPIO_NUM_42);

  // -------- 11. Disable unused RTC domains --------
  esp_sleep_pd_config(ESP_PD_DOMAIN_RTC_PERIPH, ESP_PD_OPTION_OFF);

  SerialMon.println("Alle PMU-Ausgänge deaktiviert.");
}

time_t convertToUnixTime(int yr, int mon, int day, int hr, int min, int sec) {
  tmElements_t tm;
  tm.Year = yr >= 1970 ? yr - 1970 : yr;
  tm.Month = mon;
  tm.Day = day;
  tm.Hour = hr;
  tm.Minute = min;
  tm.Second = sec;
  return makeTime(tm);
}

String unixToIsoUtc(time_t utc) {
  tmElements_t tm;
  breakTime(utc, tm);

  char buf[25];
  int year = tm.Year + 1970;

  snprintf(buf, sizeof(buf),
           "%04d-%02d-%02dT%02d:%02d:%02d.000Z",
           year, tm.Month, tm.Day, tm.Hour, tm.Minute, tm.Second);

  return String(buf);
}

void NB_IoT_status() {
  SerialMon.print("SIM status: ");
  SerialMon.println(modem.getSimStatus());

  csqValue = modem.getSignalQuality();
  SerialMon.print("Signalqualität (CSQ): ");
  SerialMon.println(csqValue);

  preferences.begin("config", false);
  preferences.putInt("csq", csqValue);
  preferences.end();

  SerialMon.print("Network connected: ");
  SerialMon.println(modem.isNetworkConnected() ? "YES" : "NO");

  SerialMon.print("GPRS connected: ");
  SerialMon.println(modem.isGprsConnected() ? "YES" : "NO");

  SerialMon.print("Operator: ");
  SerialMon.println(modem.getOperator());
}
