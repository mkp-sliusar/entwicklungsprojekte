#pragma once

// Нужны типы fs::FS, File и макрос FILE_APPEND.
// Если FS.h уже подключён раньше — этот include просто повторно не сработает.
//#ifndef FS_H
//  #include <FS.h>
//#endif
#include <Stream.h>

// Глобальная переменная, определённая в вашем проекте.
// Обязательно объявите её ОДИН раз где-нибудь в .ino как:
//   int state = 0;
extern int state;

class SerialTee : public Stream {
public:
  using BeginFn = void (*)(unsigned long);

  SerialTee(Stream& serial, BeginFn beginFn) : _serial(serial), _beginFn(beginFn) {}

  // Привязка FS и пути к логу
  void attachFS(fs::FS* fs, const char* path = "/serial.log") { _fs = fs; _path = path; }

  // Максимальный размер (по умолчанию 600 КБ)
  void setMaxSize(size_t bytes) { _maxSize = bytes; }

  // Инициализация нижележащего Serial
  void begin(unsigned long baud) {
    if (_beginFn) _beginFn(baud);
    _openLog(); // откроем файл (пишем "boot" только если разрешено логировать)
  }

  // === Stream / Print ===
  virtual size_t write(uint8_t c) override {
    size_t n = _serial.write(c);
    if (_file && _shouldLog()) {
      _file.write(c);
      _maybeRotate(1);
    }
    return n;
  }

  virtual size_t write(const uint8_t* buf, size_t size) override {
    size_t n = _serial.write(buf, size);
    if (_file && _shouldLog()) {
      _file.write(buf, size);
      _maybeRotate(size);
    }
    return n;
  }

  virtual int available() override { return _serial.available(); }
  virtual int read() override { return _serial.read(); }
  virtual int peek() override { return _serial.peek(); }

  virtual void flush() override {
    _serial.flush();
    if (_file && _shouldLog()) _file.flush();
  }

  void closeLog() { if (_file) _file.close(); }

private:
  inline bool _shouldLog() const {
    // Логируем только когда глобальная переменная state == 0
    return (state == 0);
  }

  void _openLog() {
    if (_fs) {
      _file = _fs->open(_path, FILE_APPEND);
      if (_file && _shouldLog()) {
        _file.print("\n--- boot ---\n");
        _file.flush();
      }
    }
  }

  void _maybeRotate(size_t written) {
    // Ротация учитывается только когда реально писали в файл
    _sinceCheck += written;
    if (_sinceCheck < 256) return;
    _sinceCheck = 0;

    if (_file && _file.size() >= _maxSize) {
      _file.close();
      String old = String(_path) + ".1";
      if (_fs) {
        _fs->remove(old);
        _fs->rename(_path, old);
        _file = _fs->open(_path, FILE_APPEND);
      }
    }
  }

  Stream&     _serial;
  BeginFn     _beginFn = nullptr;
  fs::FS*     _fs = nullptr;
  const char* _path = "/serial.log";
  File        _file;
  size_t      _maxSize = 250 * 1024;  // 250 КБ по умолчанию
  size_t      _sinceCheck = 0;
};

// Глобальный объект-TEE: принимает Serial (USB CDC) и функцию, вызывающую Serial.begin(...)
static SerialTee SerialMon(Serial, [](unsigned long b){ Serial.begin(b); });

